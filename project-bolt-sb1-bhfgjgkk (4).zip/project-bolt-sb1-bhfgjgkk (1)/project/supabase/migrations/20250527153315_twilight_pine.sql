/*
  # Fix recursive policies

  1. Changes
    - Remove recursive policy checks from admin_users table
    - Simplify policy logic to prevent infinite recursion
    - Update related policies in user_cities and user_subscriptions

  2. Security
    - Maintain security while avoiding recursive checks
    - Use direct role checks instead of nested queries
*/

-- Drop existing policies to replace them with non-recursive versions
DROP POLICY IF EXISTS "Manage admin roles" ON admin_users;
DROP POLICY IF EXISTS "Super admins can manage admin users" ON admin_users;
DROP POLICY IF EXISTS "Users can read own admin record" ON admin_users;

-- Create new non-recursive policies for admin_users
CREATE POLICY "Super admins can manage all"
  ON admin_users
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_roles ar
      WHERE ar.id = admin_users.role_id 
      AND ar.name = 'super_admin'
    )
  );

CREATE POLICY "Users can view own record"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Update user_cities policies to avoid recursion
DROP POLICY IF EXISTS "Only admins can modify user cities" ON user_cities;

CREATE POLICY "Admins can manage user cities"
  ON user_cities
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_roles ar
      JOIN admin_users au ON au.role_id = ar.id
      WHERE au.user_id = auth.uid() 
      AND ar.name = 'super_admin'
    )
  );

-- Update user_subscriptions policies to avoid recursion
DROP POLICY IF EXISTS "Only admins can modify subscriptions" ON user_subscriptions;
DROP POLICY IF EXISTS "Super admins can manage all subscriptions" ON user_subscriptions;

CREATE POLICY "Admins can manage subscriptions"
  ON user_subscriptions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_roles ar
      JOIN admin_users au ON au.role_id = ar.id
      WHERE au.user_id = auth.uid() 
      AND ar.name = 'super_admin'
    )
  );