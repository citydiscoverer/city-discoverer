/*
  # Fix admin policies recursion

  1. Changes
    - Drop existing policies that may cause recursion
    - Create simplified policies without circular dependencies
    - Separate read and write permissions clearly
    - Use direct role checks instead of nested queries

  2. Security
    - Maintain proper access control for super admins
    - Allow users to read their own data
    - Prevent unauthorized access
*/

-- First, drop all existing policies to start fresh
DROP POLICY IF EXISTS "Super admins manage users" ON admin_users;
DROP POLICY IF EXISTS "Admins can read own data" ON admin_users;
DROP POLICY IF EXISTS "Read admin user data" ON admin_users;
DROP POLICY IF EXISTS "Manage admin users" ON admin_users;
DROP POLICY IF EXISTS "Super admins can manage roles" ON admin_roles;
DROP POLICY IF EXISTS "Read admin roles" ON admin_roles;
DROP POLICY IF EXISTS "Manage admin roles" ON admin_roles;

-- Create simplified read policy for admin_roles
CREATE POLICY "Read admin roles"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

-- Create simplified management policy for admin_roles
CREATE POLICY "Manage admin roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_roles
    WHERE id IN (
      SELECT role_id FROM admin_users
      WHERE user_id = auth.uid()
    )
    AND name = 'super_admin'
  )
);

-- Create simplified read policy for admin_users
CREATE POLICY "Read admin users"
ON admin_users
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM admin_roles
    WHERE id IN (
      SELECT role_id FROM admin_users
      WHERE user_id = auth.uid()
    )
    AND name = 'super_admin'
  )
);

-- Create simplified management policy for admin_users
CREATE POLICY "Manage admin users"
ON admin_users
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_roles
    WHERE id IN (
      SELECT role_id FROM admin_users
      WHERE user_id = auth.uid()
    )
    AND name = 'super_admin'
  )
);