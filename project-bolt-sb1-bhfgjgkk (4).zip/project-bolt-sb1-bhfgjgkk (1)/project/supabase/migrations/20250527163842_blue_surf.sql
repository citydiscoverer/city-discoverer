/*
  # Fix city assignment for user
  
  1. Changes
    - Create cities if they don't exist
    - Assign cities to user
    - Update user metadata
*/

-- Create cities first
DO $$
DECLARE
  v_user_id uuid;
  v_cumberland_id uuid;
  v_wiley_ford_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'felixabayomi@icloud.com';

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- Create Cumberland if it doesn't exist
  INSERT INTO cities (name)
  VALUES ('Cumberland')
  ON CONFLICT (name) DO UPDATE
  SET name = EXCLUDED.name
  RETURNING id INTO v_cumberland_id;

  -- Create Wiley Ford if it doesn't exist
  INSERT INTO cities (name)
  VALUES ('Wiley Ford')
  ON CONFLICT (name) DO UPDATE
  SET name = EXCLUDED.name
  RETURNING id INTO v_wiley_ford_id;

  -- Assign cities to user
  INSERT INTO user_cities (user_id, city_id)
  VALUES 
    (v_user_id, v_cumberland_id),
    (v_user_id, v_wiley_ford_id)
  ON CONFLICT (user_id, city_id) DO NOTHING;

  -- Create city guides if they don't exist
  INSERT INTO city_guides (city_name, state)
  VALUES 
    ('Cumberland', 'MD'),
    ('Wiley Ford', 'WV')
  ON CONFLICT (city_name, state) DO NOTHING;

  -- Update user metadata
  UPDATE auth.users
  SET raw_user_meta_data = jsonb_build_object(
    'role', 'subscriber',
    'city_name', 'Cumberland',
    'state', 'MD'
  )
  WHERE id = v_user_id;

END $$;