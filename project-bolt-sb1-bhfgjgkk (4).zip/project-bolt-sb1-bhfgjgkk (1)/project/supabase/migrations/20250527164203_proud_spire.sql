/*
  # Fix Admin Role Policies

  1. Changes
    - Drop all existing policies on admin_roles table
    - Create new non-recursive policies for role management
    - Ensure proper access control for super admins
    
  2. Security
    - Enable RLS
    - Add policy for read access to all authenticated users
    - Add policy for full access to super admins only
*/

-- First, drop ALL existing policies on admin_roles
DROP POLICY IF EXISTS "Super admins manage roles v2" ON admin_roles;
DROP POLICY IF EXISTS "Allow authenticated to read roles" ON admin_roles;
DROP POLICY IF EXISTS "Manage admin roles" ON admin_roles;
DROP POLICY IF EXISTS "Read admin roles" ON admin_roles;
DROP POLICY IF EXISTS "Super admins manage roles" ON admin_roles;

-- Create new simplified policies for admin_roles
CREATE POLICY "admin_roles_read_policy"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "admin_roles_manage_policy"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);