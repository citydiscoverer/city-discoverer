/*
  # Fix admin roles policy recursion

  1. Changes
    - Remove recursive policy from admin_roles table
    - Add new non-recursive policy for admin role management
    - Add policy for super admin access

  2. Security
    - Enable RLS on admin_roles table
    - Add policies for role management
    - Ensure proper access control for admin functions
*/

-- Drop existing policies to prevent conflicts
DROP POLICY IF EXISTS "admin_roles_manage_policy" ON admin_roles;
DROP POLICY IF EXISTS "admin_roles_read_policy" ON admin_roles;

-- Create new non-recursive policies
CREATE POLICY "super_admin_manage_policy" ON admin_roles
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.user_id = auth.uid()
      AND au.role_id IN (
        SELECT id FROM admin_roles WHERE name = 'super_admin'
      )
    )
  );

CREATE POLICY "authenticated_read_policy" ON admin_roles
  FOR SELECT
  TO authenticated
  USING (true);