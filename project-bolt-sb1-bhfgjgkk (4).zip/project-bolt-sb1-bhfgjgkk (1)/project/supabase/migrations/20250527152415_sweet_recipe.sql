/*
  # Fix admin_users policy recursion

  1. Changes
    - Drop existing policies on admin_users table that cause recursion
    - Create new simplified policies that avoid circular dependencies
    - Add separate policies for different operations (read, write)
    
  2. Security
    - Maintain strict access control for admin operations
    - Allow admins to read their own data
    - Super admins retain full management capabilities
*/

-- Drop existing policies that may cause recursion
DROP POLICY IF EXISTS "Super admins can manage users" ON admin_users;
DROP POLICY IF EXISTS "Only admins can modify user cities" ON admin_users;

-- Create new policies without recursion
CREATE POLICY "Super admins manage users"
ON admin_users
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_roles ar
    WHERE ar.name = 'super_admin'
    AND ar.id IN (
      SELECT role_id 
      FROM admin_users au2 
      WHERE au2.user_id = auth.uid()
    )
  )
);

-- Allow admins to read their own data
CREATE POLICY "Admins can read own data"
ON admin_users
FOR SELECT
TO authenticated
USING (user_id = auth.uid());