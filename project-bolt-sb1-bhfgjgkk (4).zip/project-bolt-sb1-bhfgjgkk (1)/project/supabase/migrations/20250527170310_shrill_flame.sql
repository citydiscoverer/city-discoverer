/*
  # Fix admin roles policy recursion

  1. Changes
    - Remove recursive policy from admin_roles table
    - Create new policy that avoids infinite recursion
    - Keep existing policies that don't cause recursion

  2. Security
    - Maintain security by ensuring only super admins can manage roles
    - Allow authenticated users to read roles
    - Prevent unauthorized access to admin role management
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "admin_roles_manage" ON admin_roles;

-- Create new non-recursive policy for managing admin roles
CREATE POLICY "admin_roles_manage"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);

-- Keep the existing read policy as it doesn't cause recursion
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'admin_roles' 
    AND policyname = 'admin_roles_read'
  ) THEN
    CREATE POLICY "admin_roles_read"
    ON admin_roles
    FOR SELECT
    TO authenticated
    USING (true);
  END IF;
END $$;