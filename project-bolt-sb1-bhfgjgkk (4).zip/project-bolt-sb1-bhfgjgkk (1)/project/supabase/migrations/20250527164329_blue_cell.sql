/*
  # Fix admin role policies and subscription access

  1. Changes
    - Drop existing problematic policies
    - Create new non-recursive policies for admin roles
    - Add policies for user subscriptions
    - Fix user cities access

  2. Security
    - Enable RLS on all tables
    - Add appropriate policies for each table
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "super_admin_manage_policy" ON admin_roles;
DROP POLICY IF EXISTS "authenticated_read_policy" ON admin_roles;

-- Create new non-recursive policies for admin roles
CREATE POLICY "admin_roles_read"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "admin_roles_manage"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);

-- Update user_subscriptions policies
DROP POLICY IF EXISTS "Users can read their own subscription" ON user_subscriptions;
DROP POLICY IF EXISTS "Admins can manage subscriptions" ON user_subscriptions;

CREATE POLICY "read_own_subscription"
ON user_subscriptions
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "admin_manage_subscriptions"
ON user_subscriptions
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);

-- Update user_cities policies
DROP POLICY IF EXISTS "Users can read their own cities" ON user_cities;
DROP POLICY IF EXISTS "Users can add cities to their subscription" ON user_cities;

CREATE POLICY "read_own_cities"
ON user_cities
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "manage_own_cities"
ON user_cities
FOR INSERT
TO authenticated
WITH CHECK (
  user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM user_subscriptions us
    JOIN subscription_tiers st ON us.tier_id = st.id
    WHERE us.user_id = auth.uid()
    AND us.active = true
    AND us.expires_at > now()
    AND (
      SELECT COUNT(*) FROM user_cities uc
      WHERE uc.user_id = auth.uid()
    ) < st.city_limit
  )
);