/*
  # Authentication and Routing Setup

  1. New Tables
    - `user_metadata` table to store additional user information
      - `user_id` (uuid, references auth.users)
      - `city_name` (text)
      - `state` (text)
      - `role` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Functions
    - `handle_new_user()` trigger function to set up new users
    - `assign_city_to_user()` function to handle city assignment

  3. Triggers
    - After insert trigger on auth.users
*/

-- Create user_metadata table
CREATE TABLE IF NOT EXISTS user_metadata (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  city_name text NOT NULL,
  state text NOT NULL,
  role text NOT NULL DEFAULT 'subscriber',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE user_metadata ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own metadata"
  ON user_metadata
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own metadata"
  ON user_metadata
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

-- Create function to handle new user setup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_city_id uuid;
  v_city_exists boolean;
BEGIN
  -- Check if city exists
  SELECT EXISTS (
    SELECT 1 FROM city_guides 
    WHERE city_name = NEW.raw_user_meta_data->>'city_name' 
    AND state = NEW.raw_user_meta_data->>'state'
  ) INTO v_city_exists;

  -- If city doesn't exist, create it
  IF NOT v_city_exists THEN
    INSERT INTO city_guides (
      city_name,
      state,
      basic_info,
      local_attractions,
      restaurants,
      transportation,
      accommodations,
      local_tips,
      history_culture,
      audio_guides,
      walking_tours,
      seasonal_recommendations,
      architecture,
      etiquette
    ) VALUES (
      NEW.raw_user_meta_data->>'city_name',
      NEW.raw_user_meta_data->>'state',
      '{}',
      '[]',
      '[]',
      '{}',
      '[]',
      '{}',
      '{}',
      '{}',
      '[]',
      '{}',
      '{}',
      '{}'
    ) RETURNING id INTO v_city_id;
  ELSE
    SELECT id INTO v_city_id
    FROM city_guides
    WHERE city_name = NEW.raw_user_meta_data->>'city_name'
    AND state = NEW.raw_user_meta_data->>'state';
  END IF;

  -- Create user metadata
  INSERT INTO user_metadata (
    user_id,
    city_name,
    state,
    role
  ) VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'city_name',
    NEW.raw_user_meta_data->>'state',
    COALESCE(NEW.raw_user_meta_data->>'role', 'subscriber')
  );

  -- Assign city to user
  INSERT INTO user_cities (user_id, city_id)
  VALUES (NEW.id, v_city_id);

  -- Create default subscription
  INSERT INTO user_subscriptions (
    user_id,
    tier_id,
    active,
    expires_at
  )
  SELECT
    NEW.id,
    id,
    true,
    now() + interval '1 month'
  FROM subscription_tiers
  WHERE name = 'Monthly Explorer'
  LIMIT 1;

  RETURN NEW;
END;
$$;

-- Create trigger for new user setup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Create function to assign city to user
CREATE OR REPLACE FUNCTION assign_city_to_user(
  p_user_id uuid,
  p_city_name text,
  p_state text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_city_id uuid;
BEGIN
  -- Get or create city
  WITH new_city AS (
    INSERT INTO city_guides (
      city_name,
      state,
      basic_info,
      local_attractions,
      restaurants,
      transportation,
      accommodations,
      local_tips,
      history_culture,
      audio_guides,
      walking_tours,
      seasonal_recommendations,
      architecture,
      etiquette
    )
    VALUES (
      p_city_name,
      p_state,
      '{}',
      '[]',
      '[]',
      '{}',
      '[]',
      '{}',
      '{}',
      '{}',
      '[]',
      '{}',
      '{}',
      '{}'
    )
    ON CONFLICT ON CONSTRAINT unique_city_state
    DO UPDATE SET updated_at = now()
    RETURNING id
  )
  SELECT id INTO v_city_id
  FROM new_city;

  -- Assign city to user
  INSERT INTO user_cities (user_id, city_id)
  VALUES (p_user_id, v_city_id)
  ON CONFLICT DO NOTHING;

  RETURN v_city_id;
END;
$$;