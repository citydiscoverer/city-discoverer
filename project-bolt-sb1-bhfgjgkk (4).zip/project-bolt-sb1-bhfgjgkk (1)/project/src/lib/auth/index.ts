import { SignJWT, jwtVerify } from 'jose';
import { randomBytes, pbkdf2Sync } from 'crypto';
import { db } from '../db';
import { users, sessions } from '../db/schema';
import { eq } from 'drizzle-orm';

const JWT_SECRET = new TextEncoder().encode(
  process.env.VITE_JWT_SECRET || randomBytes(32).toString('hex')
);

const JWT_ISSUER = 'city-discoverer';
const JWT_AUDIENCE = 'city-discoverer-web';

// Helper functions
const generateId = () => randomBytes(16).toString('hex');
const generateToken = () => randomBytes(32).toString('hex');

const hashPassword = (password: string, salt: string) => {
  return pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
};

export interface User {
  id: string;
  email: string;
  metadata?: Record<string, any>;
  isAdmin?: boolean;
}

export interface Session {
  id: string;
  token: string;
  userId: string;
  expiresAt: Date;
}

export const auth = {
  // Sign up new user
  async signUp(email: string, password: string, metadata?: Record<string, any>): Promise<User> {
    const salt = randomBytes(16).toString('hex');
    const passwordHash = hashPassword(password, salt);
    const id = generateId();

    try {
      await db.insert(users).values({
        id,
        email,
        passwordHash: `${salt}:${passwordHash}`,
        metadata: metadata || {},
      });

      return { id, email, metadata };
    } catch (error) {
      console.error('Failed to create user:', error);
      throw new Error('Failed to create user');
    }
  },

  // Sign in existing user
  async signIn(email: string, password: string): Promise<{ user: User; session: Session }> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    
    if (!user) {
      throw new Error('Invalid credentials');
    }

    const [salt, storedHash] = user.passwordHash.split(':');
    const passwordHash = hashPassword(password, salt);

    if (passwordHash !== storedHash) {
      throw new Error('Invalid credentials');
    }

    // Create session
    const sessionId = generateId();
    const token = generateToken();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

    await db.insert(sessions).values({
      id: sessionId,
      userId: user.id,
      token,
      expiresAt,
    });

    // Check if user is admin
    const [adminUser] = await db
      .select()
      .from(users)
      .innerJoin('admin_users', eq(users.id, 'admin_users.user_id'))
      .where(eq(users.id, user.id));

    const userData: User = {
      id: user.id,
      email: user.email,
      metadata: user.metadata as Record<string, any>,
      isAdmin: !!adminUser
    };

    return {
      user: userData,
      session: {
        id: sessionId,
        token,
        userId: user.id,
        expiresAt
      }
    };
  },

  // Sign out user
  async signOut(token: string): Promise<void> {
    await db.delete(sessions).where(eq(sessions.token, token));
  },

  // Get user by session token
  async getUserByToken(token: string): Promise<User | null> {
    const [session] = await db
      .select()
      .from(sessions)
      .where(eq(sessions.token, token))
      .where('expires_at > datetime()');

    if (!session) return null;

    const [user] = await db.select().from(users).where(eq(users.id, session.userId));
    if (!user) {
      await db.delete(sessions).where(eq(sessions.token, token));
      return null;
    }

    const [adminUser] = await db
      .select()
      .from(users)
      .innerJoin('admin_users', eq(users.id, 'admin_users.user_id'))
      .where(eq(users.id, user.id));

    return {
      id: user.id,
      email: user.email,
      metadata: user.metadata as Record<string, any>,
      isAdmin: !!adminUser
    };
  },

  // Update user metadata
  async updateUserMetadata(userId: string, metadata: Record<string, any>): Promise<void> {
    await db
      .update(users)
      .set({ metadata, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }
};