import React, { useState, useEffect } from 'react';
import { Users, Building, MapPin, Plus, Trash2, Check, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface User {
  id: string;
  email: string;
}

interface SubscriptionTier {
  id: string;
  name: string;
  max_cities: number;
  price: number;
}

interface UserSubscription {
  id: string;
  user_id: string;
  subscription_tier_id: string;
}

interface City {
  id: string;
  name: string;
}

interface UserCity {
  id: string;
  user_id: string;
  city_id: string;
}

const SubscriptionManager: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [subscriptionTiers, setSubscriptionTiers] = useState<SubscriptionTier[]>([]);
  const [userSubscriptions, setUserSubscriptions] = useState<UserSubscription[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [userCities, setUserCities] = useState<UserCity[]>([]);
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [isAddingCity, setIsAddingCity] = useState(false);
  const [selectedCity, setSelectedCity] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch users
      const { data: usersData } = await supabase.auth.admin.listUsers();
      setUsers(usersData?.users || []);

      // Fetch subscription tiers
      const { data: tiersData } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('price');
      setSubscriptionTiers(tiersData || []);

      // Fetch user subscriptions
      const { data: subscriptionsData } = await supabase
        .from('user_subscriptions')
        .select('*');
      setUserSubscriptions(subscriptionsData || []);

      // Fetch cities
      const { data: citiesData } = await supabase
        .from('cities')
        .select('*')
        .order('name');
      setCities(citiesData || []);

      // Fetch user cities
      const { data: userCitiesData } = await supabase
        .from('user_cities')
        .select('*');
      setUserCities(userCitiesData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      setErrorMessage('Error fetching data. Please try again.');
    }
  };

  const handleUpdateSubscription = async (userId: string, tierId: string) => {
    try {
      const existingSubscription = userSubscriptions.find(sub => sub.user_id === userId);

      if (existingSubscription) {
        const { error } = await supabase
          .from('user_subscriptions')
          .update({ subscription_tier_id: tierId })
          .eq('user_id', userId);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('user_subscriptions')
          .insert({ user_id: userId, subscription_tier_id: tierId });

        if (error) throw error;
      }

      setSuccessMessage('Subscription updated successfully');
      fetchData();
    } catch (error) {
      console.error('Error updating subscription:', error);
      setErrorMessage('Error updating subscription. Please try again.');
    }
  };

  const handleAddCity = async () => {
    if (!selectedUser || !selectedCity) return;

    try {
      const userSubscription = userSubscriptions.find(sub => sub.user_id === selectedUser);
      if (!userSubscription) {
        setErrorMessage('User must have a subscription before adding cities');
        return;
      }

      const subscriptionTier = subscriptionTiers.find(tier => tier.id === userSubscription.subscription_tier_id);
      const currentCityCount = userCities.filter(uc => uc.user_id === selectedUser).length;

      if (subscriptionTier && currentCityCount >= subscriptionTier.max_cities) {
        setErrorMessage(`User has reached their maximum city limit (${subscriptionTier.max_cities})`);
        return;
      }

      const { error } = await supabase
        .from('user_cities')
        .insert({ user_id: selectedUser, city_id: selectedCity });

      if (error) throw error;

      setSuccessMessage('City added successfully');
      setIsAddingCity(false);
      setSelectedCity('');
      fetchData();
    } catch (error) {
      console.error('Error adding city:', error);
      setErrorMessage('Error adding city. Please try again.');
    }
  };

  const handleRemoveCity = async (userId: string, cityId: string) => {
    try {
      const { error } = await supabase
        .from('user_cities')
        .delete()
        .eq('user_id', userId)
        .eq('city_id', cityId);

      if (error) throw error;

      setSuccessMessage('City removed successfully');
      fetchData();
    } catch (error) {
      console.error('Error removing city:', error);
      setErrorMessage('Error removing city. Please try again.');
    }
  };

  const getUserSubscriptionTier = (userId: string) => {
    const subscription = userSubscriptions.find(sub => sub.user_id === userId);
    if (!subscription) return null;
    return subscriptionTiers.find(tier => tier.id === subscription.subscription_tier_id);
  };

  const getUserCities = (userId: string) => {
    const cityIds = userCities
      .filter(uc => uc.user_id === userId)
      .map(uc => uc.city_id);
    return cities.filter(city => cityIds.includes(city.id));
  };

  return (
    <div className="space-y-8">
      {(successMessage || errorMessage) && (
        <div className={`p-4 rounded-md ${
          successMessage ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
        }`}>
          {successMessage || errorMessage}
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium leading-6 text-gray-900">User Subscriptions</h3>
          <p className="mt-1 text-sm text-gray-500">Manage user subscriptions and city access</p>
        </div>

        <div className="divide-y divide-gray-200">
          {users.map(user => (
            <div key={user.id} className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Users className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-900 font-medium">{user.email}</span>
                </div>
                
                <select
                  className="ml-4 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  value={getUserSubscriptionTier(user.id)?.id || ''}
                  onChange={(e) => handleUpdateSubscription(user.id, e.target.value)}
                >
                  <option value="">No Subscription</option>
                  {subscriptionTiers.map(tier => (
                    <option key={tier.id} value={tier.id}>
                      {tier.name} ({tier.max_cities} cities - ${tier.price})
                    </option>
                  ))}
                </select>
              </div>

              <div className="pl-8">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium text-gray-700">Assigned Cities</h4>
                  {selectedUser === user.id && isAddingCity ? (
                    <div className="flex items-center space-x-2">
                      <select
                        className="pl-3 pr-10 py-2 text-sm border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 rounded-md"
                        value={selectedCity}
                        onChange={(e) => setSelectedCity(e.target.value)}
                      >
                        <option value="">Select a city</option>
                        {cities.map(city => (
                          <option key={city.id} value={city.id}>{city.name}</option>
                        ))}
                      </select>
                      <button
                        onClick={handleAddCity}
                        className="p-2 text-green-600 hover:text-green-700"
                      >
                        <Check className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => {
                          setIsAddingCity(false);
                          setSelectedCity('');
                        }}
                        className="p-2 text-gray-600 hover:text-gray-700"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        setSelectedUser(user.id);
                        setIsAddingCity(true);
                      }}
                      className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add City
                    </button>
                  )}
                </div>

                <div className="space-y-2">
                  {getUserCities(user.id).map(city => (
                    <div
                      key={city.id}
                      className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-md"
                    >
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-700">{city.name}</span>
                      </div>
                      <button
                        onClick={() => handleRemoveCity(user.id, city.id)}
                        className="p-1 text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SubscriptionManager;