import React from 'react';
import { Link } from 'react-router-dom';
import { LogIn, MapPin, Calendar, Star, Shield } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const LandingPage: React.FC = () => {
  const { user, isAdmin } = useAuth();

  return (
    <div className="min-h-screen bg-white">
      <video
        src="https://res.cloudinary.com/do26xsbby/video/upload/v1748190208/Discoverer_Logo_lkxor3.mp4"
        autoPlay
        loop
        muted
        playsInline
        className="absolute top-4 left-4 w-28 rounded-lg z-50"
      />
      
      <nav className="absolute top-4 right-4 z-50 flex items-center space-x-4">
        {isAdmin ? (
          <Link
            to="/admin"
            className="inline-flex items-center px-4 py-2 bg-black/60 text-white text-sm font-medium rounded-lg hover:bg-black/80 transition-colors"
          >
            <Shield className="w-4 h-4 mr-2" />
            Admin Dashboard
          </Link>
        ) : (
          <Link
            to="/login"
            className="inline-flex items-center px-4 py-2 bg-black/60 text-white text-sm font-medium rounded-lg hover:bg-black/80 transition-colors"
          >
            <LogIn className="w-4 h-4 mr-2" />
            Sign In
          </Link>
        )}
      </nav>

      <div className="relative min-h-screen flex flex-col">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/3617500/pexels-photo-3617500.jpeg"
            alt="City skyline"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>

        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen text-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-8">
            Welcome to City Discoverer
          </h1>
          
          <p className="max-w-2xl mx-auto text-xl sm:text-2xl text-gray-200 mb-12">
            Your personal guide to exploring cities around the world. Discover local attractions, 
            dining spots, and hidden gems.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl w-full mb-12">
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-lg p-6 border border-white border-opacity-20">
              <MapPin className="w-8 h-8 text-blue-400 mb-4 mx-auto" />
              <h3 className="text-xl font-semibold text-white mb-2">Local Insights</h3>
              <p className="text-gray-200">Discover hidden gems and local favorites</p>
            </div>
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-lg p-6 border border-white border-opacity-20">
              <Calendar className="w-8 h-8 text-blue-400 mb-4 mx-auto" />
              <h3 className="text-xl font-semibold text-white mb-2">Custom Itineraries</h3>
              <p className="text-gray-200">Personalized travel plans just for you</p>
            </div>
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-lg p-6 border border-white border-opacity-20">
              <Star className="w-8 h-8 text-blue-400 mb-4 mx-auto" />
              <h3 className="text-xl font-semibold text-white mb-2">Expert Reviews</h3>
              <p className="text-gray-200">Curated recommendations you can trust</p>
            </div>
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-lg p-6 border border-white border-opacity-20">
              <Shield className="w-8 h-8 text-blue-400 mb-4 mx-auto" />
              <h3 className="text-xl font-semibold text-white mb-2">Travel Tips</h3>
              <p className="text-gray-200">Essential insights for safe exploration</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              to="/subscribe"
              className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 shadow-lg hover:shadow-xl transition-all duration-200"
            >
              Get Started
            </Link>
            <a
              href="https://citydiscoverer.ai/contact"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center px-8 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-gray-900 transition-all duration-200"
            >
              Learn More
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;