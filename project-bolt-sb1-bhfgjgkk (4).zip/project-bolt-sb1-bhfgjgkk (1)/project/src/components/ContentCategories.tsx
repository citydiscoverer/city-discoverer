import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { MapPin, Utensils, Navigation, Building, Star, History, Headphones, Map, Sun, Shield, Info } from 'lucide-react';
import { supabase } from '../lib/supabase';

const CATEGORIES = [
  { id: '1', name: 'Basic Information', icon: Info },
  { id: '2', name: 'Local Attractions', icon: MapPin },
  { id: '3', name: 'Restaurants & Dining', icon: Utensils },
  { id: '4', name: 'Transportation', icon: Navigation },
  { id: '5', name: 'Accommodations', icon: Building },
  { id: '6', name: 'Local Tips & Secrets', icon: Star },
  { id: '7', name: 'History & Culture', icon: History },
  { id: '8', name: 'Audio & Interactive Guides', icon: Headphones },
  { id: '9', name: 'Curated Walking Tours', icon: Map },
  { id: '10', name: 'Seasonal Recommendations', icon: Sun },
  { id: '11', name: 'Architectural Highlights', icon: Building },
  { id: '12', name: 'Cultural Etiquette', icon: Shield }
];

const ContentCategories: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { categoryId, cityId } = useParams();
  const [content, setContent] = useState<any[]>([]);

  useEffect(() => {
    if (categoryId) {
      setSelectedCategory(categoryId);
    }

    const fetchContent = async () => {
      if (!cityId) return;

      const { data, error } = await supabase
        .from('content')
        .select('*')
        .eq('city_id', cityId);

      if (error) {
        console.error('Error fetching content:', error);
        return;
      }

      setContent(data || []);
    };

    fetchContent();

    // Set up real-time subscription
    const subscription = supabase
      .channel('content-changes')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'content', filter: `city_id=eq.${cityId}` },
        (payload) => {
          console.log('Content change received:', payload);
          fetchContent();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [categoryId, cityId]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-gray-900">Explore Categories</h2>
      <p className="text-gray-600">Choose a category to discover more about the city</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {CATEGORIES.map((category) => (
          <CategoryCard 
            key={category.id}
            id={category.id}
            title={category.name}
            icon={category.icon}
            isSelected={category.id === selectedCategory}
            onClick={() => setSelectedCategory(category.id)}
          />
        ))}
      </div>
    </div>
  );
};

export default ContentCategories;