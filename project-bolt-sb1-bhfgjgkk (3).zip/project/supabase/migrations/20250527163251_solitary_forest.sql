/*
  # Add RPC Function and Update Policies

  1. New Functions
    - `add_city_to_subscription`: RPC function to add a city to a user's subscription
    - Checks subscription limits and handles city assignment

  2. Security
    - Function is accessible to authenticated users only
    - Validates subscription status and limits
*/

-- Create the RPC function to add a city to a subscription
CREATE OR REPLACE FUNCTION add_city_to_subscription(city_uuid uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_subscription record;
  v_tier record;
  v_current_city_count integer;
BEGIN
  -- Get the current user's ID
  v_user_id := auth.uid();
  
  -- Check if user exists
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Get user's subscription and tier details
  SELECT us.*, st.city_limit
  INTO v_subscription
  FROM user_subscriptions us
  JOIN subscription_tiers st ON us.tier_id = st.id
  WHERE us.user_id = v_user_id
  AND us.active = true
  AND us.expires_at > NOW();

  -- Check if user has an active subscription
  IF v_subscription IS NULL THEN
    RETURN false;
  END IF;

  -- Count current cities
  SELECT COUNT(*)
  INTO v_current_city_count
  FROM user_cities
  WHERE user_id = v_user_id;

  -- Check if user has reached their city limit
  IF v_current_city_count >= v_subscription.city_limit THEN
    RETURN false;
  END IF;

  -- Check if city is already assigned
  IF EXISTS (
    SELECT 1 FROM user_cities
    WHERE user_id = v_user_id AND city_id = city_uuid
  ) THEN
    RETURN true;
  END IF;

  -- Add the city
  INSERT INTO user_cities (user_id, city_id)
  VALUES (v_user_id, city_uuid);

  RETURN true;
END;
$$;