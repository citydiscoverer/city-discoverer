/*
  # Add roles management tables and policies

  1. New Tables
    - `admin_roles`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `permissions` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `admin_users`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `role_id` (uuid, references admin_roles)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for super admin access
    - Add policies for role-based access
*/

-- Create admin_roles table
CREATE TABLE IF NOT EXISTS admin_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  permissions jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users ON DELETE CASCADE,
  role_id uuid REFERENCES admin_roles ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE admin_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Insert default super admin role
INSERT INTO admin_roles (name, permissions) VALUES (
  'super_admin',
  '{
    "cities": {"create": true, "read": true, "update": true, "delete": true},
    "categories": {"create": true, "read": true, "update": true, "delete": true},
    "content": {"create": true, "read": true, "update": true, "delete": true},
    "roles": {"create": true, "read": true, "update": true, "delete": true},
    "users": {"create": true, "read": true, "update": true, "delete": true}
  }'
);

-- Create policies for admin_roles
CREATE POLICY "Super admins can manage roles"
  ON admin_roles
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.user_id = auth.uid()
      AND EXISTS (
        SELECT 1 FROM admin_roles ar
        WHERE ar.id = au.role_id
        AND ar.name = 'super_admin'
      )
    )
  );

-- Create policies for admin_users
CREATE POLICY "Super admins can manage users"
  ON admin_users
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.user_id = auth.uid()
      AND EXISTS (
        SELECT 1 FROM admin_roles ar
        WHERE ar.id = au.role_id
        AND ar.name = 'super_admin'
      )
    )
  );

-- Create function to check if user is super admin
CREATE OR REPLACE FUNCTION is_super_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON ar.id = au.role_id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;