/*
  # Update content for Wiley Ford

  1. Changes
    - Updates content for Local Attractions category
    - Updates content for Restaurants & Dining category
    - Adds structured JSONB data for both categories
*/

DO $$ 
DECLARE
  wiley_ford_id uuid;
  attractions_id uuid;
  dining_id uuid;
BEGIN
  -- Get Wiley Ford city ID
  SELECT id INTO wiley_ford_id FROM cities WHERE name = 'Wiley Ford, WV';
  
  -- Get category IDs
  SELECT id INTO attractions_id FROM categories WHERE name = 'Local Attractions';
  SELECT id INTO dining_id FROM categories WHERE name = 'Restaurants & Dining';

  -- Update Local Attractions content
  UPDATE content 
  SET 
    title = 'Wiley Ford, WV - Local Attractions',
    description = 'Must-visit spots and attractions in and around Wiley Ford',
    content = jsonb_build_object(
      'emoji', '🌆',
      'tagline', 'Discover the hidden gems and scenic spots of Wiley Ford',
      'sections', jsonb_build_array(
        jsonb_build_object(
          'title', 'Notable Attractions',
          'icon', 'MapPin',
          'items', jsonb_build_array(
            jsonb_build_object(
              'name', 'Knobley Tunnel Trail',
              'description', 'A scenic trail perfect for hiking and biking enthusiasts.',
              'tags', jsonb_build_array('Hiking', 'Biking', 'Nature')
            ),
            jsonb_build_object(
              'name', 'Helmstetter''s Curve',
              'description', 'A famous railroad curve offering picturesque views, popular among photographers.',
              'tags', jsonb_build_array('Scenic', 'Photography', 'Historic')
            ),
            jsonb_build_object(
              'name', 'Brush Tunnel',
              'description', 'Historic railroad tunnel now part of a biking trail.',
              'tags', jsonb_build_array('Historic', 'Biking', 'Trail')
            ),
            jsonb_build_object(
              'name', 'Great Allegheny Passage & C&O Canal Towpath',
              'description', 'Starting points for long-distance biking and hiking adventures.',
              'tags', jsonb_build_array('Biking', 'Hiking', 'Adventure')
            )
          )
        )
      )
    )
  WHERE city_id = wiley_ford_id AND category_id = attractions_id;

  -- Update Restaurants & Dining content
  UPDATE content 
  SET 
    title = 'Wiley Ford, WV - Restaurants & Dining',
    description = 'Local dining options and eateries in Wiley Ford',
    content = jsonb_build_object(
      'emoji', '🍽️',
      'tagline', 'Savor the local flavors of Wiley Ford',
      'sections', jsonb_build_array(
        jsonb_build_object(
          'title', 'Local Restaurants',
          'icon', 'Utensils',
          'items', jsonb_build_array(
            jsonb_build_object(
              'name', 'Hummingbird Café',
              'cuisine', 'American',
              'priceRange', '$$',
              'highlights', jsonb_build_array(
                'Home-style meals',
                'Airport view dining',
                'Fresh baked goods'
              ),
              'special', true
            ),
            jsonb_build_object(
              'name', 'Patrick''s Restaurant',
              'cuisine', 'American',
              'priceRange', '$$',
              'highlights', jsonb_build_array(
                'Casual dining',
                'American classics',
                'Family-friendly atmosphere'
              )
            ),
            jsonb_build_object(
              'name', 'Oscar''s Restaurant',
              'cuisine', 'American Diner',
              'priceRange', '$',
              'highlights', jsonb_build_array(
                'Hearty breakfasts',
                'Friendly service',
                'Local favorite'
              )
            )
          )
        )
      )
    )
  WHERE city_id = wiley_ford_id AND category_id = dining_id;
END $$;