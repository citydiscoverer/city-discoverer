/*
  # Fix admin_users policies recursion

  1. Changes
    - Drop existing policies on admin_users table that are causing recursion
    - Create new policies with proper conditions that avoid recursion
    
  2. Security
    - Maintain RLS on admin_users table
    - Add policies for:
      - Super admins can manage all admin users
      - Users can read their own admin user record
*/

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS "Manage admin users" ON admin_users;
DROP POLICY IF EXISTS "Read admin users base" ON admin_users;

-- Create new non-recursive policies
CREATE POLICY "Super admins can manage admin users"
ON admin_users
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_roles ar
    WHERE ar.name = 'super_admin'
    AND ar.id = admin_users.role_id
    AND admin_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can read own admin record"
ON admin_users
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
);