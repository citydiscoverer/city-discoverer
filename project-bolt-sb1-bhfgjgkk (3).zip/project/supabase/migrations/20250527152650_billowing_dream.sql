/*
  # Fix admin policies recursion

  1. Changes
    - Drop existing policies that may cause recursion
    - Create new simplified policies for admin_roles and admin_users
    - Avoid circular references in policy definitions
    - Ensure proper access control while preventing infinite recursion

  2. Security
    - Maintain proper access control for super admins
    - Allow users to read their own data
    - Prevent unauthorized access
*/

-- First, drop all existing policies to start fresh
DROP POLICY IF EXISTS "Read admin roles" ON admin_roles;
DROP POLICY IF EXISTS "Manage admin roles" ON admin_roles;
DROP POLICY IF EXISTS "Read admin users" ON admin_users;
DROP POLICY IF EXISTS "Manage admin users" ON admin_users;

-- Create base policy for admin_roles
CREATE POLICY "Read admin roles base"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

-- Create management policy for admin_roles that avoids recursion
CREATE POLICY "Manage admin roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_roles ar
    WHERE ar.name = 'super_admin'
    AND ar.id IN (
      SELECT role_id FROM admin_users
      WHERE user_id = auth.uid()
    )
  )
);

-- Create base policy for admin_users
CREATE POLICY "Read admin users base"
ON admin_users
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM admin_roles ar
    WHERE ar.name = 'super_admin'
    AND ar.id IN (
      SELECT role_id FROM admin_users
      WHERE user_id = auth.uid()
    )
  )
);

-- Create management policy for admin_users that avoids recursion
CREATE POLICY "Manage admin users"
ON admin_users
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_roles ar
    WHERE ar.name = 'super_admin'
    AND ar.id IN (
      SELECT role_id FROM admin_users
      WHERE user_id = auth.uid()
    )
  )
);