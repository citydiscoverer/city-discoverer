/*
  # Fix Admin Role Policies

  1. Changes
    - Drop existing problematic policies that cause recursion
    - Create new simplified policies for admin roles and users
    - Ensure policies use direct role checks without circular references

  2. Security
    - Maintain proper access control for super admins
    - Allow read access to authenticated users
    - Prevent unauthorized modifications
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Super admins manage roles v2" ON admin_roles;
DROP POLICY IF EXISTS "Allow authenticated to read roles" ON admin_roles;
DROP POLICY IF EXISTS "Manage admin roles" ON admin_roles;

-- Create new simplified policies for admin_roles
CREATE POLICY "Read admin roles"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Manage admin roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);