/*
  # User Subscription and Cities Setup

  1. Changes
    - Ensures cities exist with proper state information
    - Creates legacy user subscription tier
    - Assigns subscription and cities to specific user
    
  2. Security
    - Uses existing RLS policies
    - Respects all table constraints
*/

-- First, ensure the cities exist with proper state information
INSERT INTO cities (name, state)
VALUES 
  ('Cumberland', 'MD'),
  ('Wiley Ford', 'WV')
ON CONFLICT ON CONSTRAINT cities_name_state_key 
DO NOTHING;

-- Create a special tier for legacy users if it doesn't exist
INSERT INTO subscription_tiers (name, city_limit, price)
VALUES ('Legacy User', 2, 0)
ON CONFLICT ON CONSTRAINT subscription_tiers_name_key 
DO NOTHING;

-- Get the IDs we need and create subscription
WITH user_data AS (
  SELECT id 
  FROM auth.users 
  WHERE email = 'felixabayomii@icloud.com'
  LIMIT 1
),
tier_data AS (
  SELECT id 
  FROM subscription_tiers 
  WHERE name = 'Legacy User'
  LIMIT 1
),
subscription_insert AS (
  INSERT INTO user_subscriptions (user_id, tier_id, active, expires_at)
  SELECT 
    ud.id,
    td.id,
    true,
    '2099-12-31 23:59:59'::timestamptz
  FROM user_data ud
  CROSS JOIN tier_data td
  ON CONFLICT ON CONSTRAINT user_subscriptions_user_id_key 
  DO UPDATE SET 
    tier_id = EXCLUDED.tier_id,
    active = EXCLUDED.active,
    expires_at = EXCLUDED.expires_at
  RETURNING user_id
),
cities_data AS (
  SELECT id
  FROM cities
  WHERE (name = 'Cumberland' AND state = 'MD')
     OR (name = 'Wiley Ford' AND state = 'WV')
)
-- Add user cities
INSERT INTO user_cities (user_id, city_id)
SELECT 
  si.user_id,
  cd.id
FROM subscription_insert si
CROSS JOIN cities_data cd
ON CONFLICT ON CONSTRAINT user_cities_user_id_city_id_key 
DO NOTHING;