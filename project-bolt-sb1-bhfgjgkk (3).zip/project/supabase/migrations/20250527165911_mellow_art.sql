/*
  # Create Super Admin Role and User

  1. Changes
    - Creates super_admin role with full permissions
    - Creates admin user with super_admin role
    - Sets up proper authentication

  2. Security
    - Uses secure password hashing
    - Sets up proper role-based access
*/

-- First ensure the super_admin role exists
INSERT INTO admin_roles (name, permissions)
VALUES (
  'super_admin',
  jsonb_build_object(
    'cities', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'categories', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'content', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'roles', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'users', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true)
  )
)
ON CONFLICT (name) 
DO UPDATE SET permissions = EXCLUDED.permissions
RETURNING id;

-- Create the auth user if it doesn't exist
DO $$
DECLARE
  v_user_id uuid;
  v_role_id uuid;
BEGIN
  -- Get super_admin role id
  SELECT id INTO v_role_id
  FROM admin_roles
  WHERE name = 'super_admin';

  -- Create the user using Supabase's auth.users() function
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'support@citydiscoverer.ai';

  IF v_user_id IS NULL THEN
    v_user_id := gen_random_uuid();
    
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change_token_current,
      email_change_token_new,
      recovery_token
    )
    VALUES (
      v_user_id,
      '00000000-0000-0000-0000-000000000000',
      'support@citydiscoverer.ai',
      crypt('Olusola1977?', gen_salt('bf')),
      now(),
      '{"role": "super_admin"}'::jsonb,
      now(),
      now(),
      encode(gen_random_bytes(32), 'hex'),
      encode(gen_random_bytes(32), 'hex'),
      encode(gen_random_bytes(32), 'hex'),
      encode(gen_random_bytes(32), 'hex')
    );
  END IF;

  -- Create admin user record
  INSERT INTO admin_users (user_id, role_id)
  VALUES (v_user_id, v_role_id)
  ON CONFLICT (user_id) DO UPDATE 
  SET role_id = v_role_id;

END $$;