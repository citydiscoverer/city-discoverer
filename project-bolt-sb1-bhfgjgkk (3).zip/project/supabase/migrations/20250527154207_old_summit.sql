/*
  # Fix admin roles policy recursion

  1. Changes
    - Remove recursive policy from admin_roles table
    - Add new policy with direct user role check
    - Keep existing base read policy

  2. Security
    - Maintain RLS on admin_roles table
    - Ensure authenticated users can still read their roles
    - Super admins can still manage all roles
*/

-- Drop the problematic policy
DROP POLICY IF EXISTS "Manage admin roles" ON admin_roles;

-- Create new non-recursive policy
CREATE POLICY "Super admins can manage roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);