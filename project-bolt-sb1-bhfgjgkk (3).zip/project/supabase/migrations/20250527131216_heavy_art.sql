/*
  # Update RLS policies for subscription-based access

  1. Changes
    - Drop and recreate cities access policy
    - Update user_cities policies to handle subscription limits
    - Update user_subscriptions policies for admin access
    - Add helper function for city access checks

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Add admin-only policies
*/

-- Enable RLS on cities table
ALTER TABLE cities ENABLE ROW LEVEL SECURITY;

-- Cities policies
DROP POLICY IF EXISTS "Users can access cities in their subscription" ON cities;
CREATE POLICY "Users can access cities in their subscription"
  ON cities
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM user_cities
      WHERE user_cities.user_id = auth.uid()
      AND user_cities.city_id = cities.id
    )
  );

-- Update user_cities policies
DROP POLICY IF EXISTS "Users can read their own cities" ON user_cities;
DROP POLICY IF EXISTS "Users can add cities to their subscription" ON user_cities;

CREATE POLICY "Users can read their own cities"
  ON user_cities
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can add cities to their subscription"
  ON user_cities
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    (
      SELECT COUNT(*) < city_limit
      FROM user_subscriptions us
      JOIN subscription_tiers st ON us.tier_id = st.id
      WHERE us.user_id = auth.uid()
    )
  );

-- Update user_subscriptions policies
DROP POLICY IF EXISTS "Users can view their own subscription" ON user_subscriptions;
DROP POLICY IF EXISTS "Super admins can manage all subscriptions" ON user_subscriptions;

CREATE POLICY "Users can view their own subscription"
  ON user_subscriptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Super admins can manage all subscriptions"
  ON user_subscriptions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM admin_users au
      JOIN admin_roles ar ON au.role_id = ar.id
      WHERE au.user_id = auth.uid()
      AND ar.name = 'super_admin'
    )
  );

-- Helper function for checking city access
DROP FUNCTION IF EXISTS public.has_city_access(uuid);
CREATE OR REPLACE FUNCTION public.has_city_access(city_uuid uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_cities uc
    WHERE uc.user_id = auth.uid()
    AND uc.city_id = city_uuid
  );
END;
$$;