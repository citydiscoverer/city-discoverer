/*
  # Add state column to cities table

  1. Changes
    - Add state column to cities table
    - Update cities table constraints
    - Update unique constraint to include state
    - Migrate existing data
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add state column to cities table
ALTER TABLE cities 
ADD COLUMN state text NOT NULL DEFAULT 'MD';

-- Drop existing unique constraint on name
ALTER TABLE cities 
DROP CONSTRAINT IF EXISTS cities_name_key;

-- Add new unique constraint on name and state combination
ALTER TABLE cities 
ADD CONSTRAINT cities_name_state_key UNIQUE (name, state);

-- Update existing cities with default state
UPDATE cities 
SET state = 'MD' 
WHERE state = 'MD';

-- Remove the default constraint now that existing data is updated
ALTER TABLE cities 
ALTER COLUMN state DROP DEFAULT;

-- Ensure RLS is enabled
ALTER TABLE cities ENABLE ROW LEVEL SECURITY;

-- Recreate the cities access policy to include state
DROP POLICY IF EXISTS "Users can access cities in their subscription" ON cities;
CREATE POLICY "Users can access cities in their subscription"
  ON cities
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM user_cities
      WHERE user_cities.user_id = auth.uid()
      AND user_cities.city_id = cities.id
    )
  );