import { supabase } from './db/index';

// Export the Supabase client
export { supabase as db };

// Helper functions for common database operations
export const statements = {
  // Users
  getUserByEmail: async (email: string) => {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();
    if (error) throw error;
    return data;
  },

  getUserById: async (id: string) => {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  // Cities
  getAllCities: async () => {
    const { data, error } = await supabase
      .from('cities')
      .select('*')
      .order('name');
    if (error) throw error;
    return data;
  },

  getCityById: async (id: string) => {
    const { data, error } = await supabase
      .from('cities')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  // Categories
  getAllCategories: async () => {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('name');
    if (error) throw error;
    return data;
  },

  getCategoryById: async (id: string) => {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  // Content
  getContentByCityAndCategory: async (cityId: string, categoryId: string) => {
    const { data, error } = await supabase
      .from('content')
      .select('*')
      .eq('city_id', cityId)
      .eq('category_id', categoryId)
      .single();
    if (error) throw error;
    return data;
  },

  // User Cities
  getUserCities: async (userId: string) => {
    const { data, error } = await supabase
      .from('cities')
      .select('*')
      .eq('user_id', userId)
      .order('name');
    if (error) throw error;
    return data;
  }
};