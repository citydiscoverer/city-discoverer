import { createClient } from '@supabase/supabase-js';

if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
  console.error('Missing Supabase environment variables');
  throw new Error('Missing Supabase environment variables');
}

console.log('Initializing Supabase client...');
console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL);
console.log('Has Anon Key:', !!import.meta.env.VITE_SUPABASE_ANON_KEY);

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

async function seedData() {
  try {
    console.log('Starting data seeding...');

    // Check if we can connect to Supabase
    const { data: test, error: testError } = await supabase.from('cities').select('count');
    if (testError) {
      console.error('Error connecting to Supabase:', testError);
      return;
    }
    console.log('Successfully connected to Supabase');

    // Insert cities
    console.log('Seeding cities...');
    const { data: cities, error: citiesError } = await supabase
      .from('cities')
      .upsert([
        { name: 'Cumberland' },
        { name: 'Portland' },
        { name: 'Seattle' },
      ], { onConflict: 'name' })
      .select();

    if (citiesError) {
      console.error('Error seeding cities:', citiesError);
      return;
    }
    console.log('Cities seeded successfully:', cities);

    // Insert categories
    console.log('Seeding categories...');
    const { data: categories, error: categoriesError } = await supabase
      .from('categories')
      .upsert([
        { name: 'Basic Information' },
        { name: 'Local Attractions' },
        { name: 'Restaurants & Dining' },
      ], { onConflict: 'name' })
      .select();

    if (categoriesError) {
      console.error('Error seeding categories:', categoriesError);
      return;
    }
    console.log('Categories seeded successfully:', categories);

    // Insert sample content
    if (cities && categories) {
      console.log('Seeding content...');
      const sampleContent = {
        city_id: cities[0].id,
        category_id: categories[0].id,
        title: 'Basic Information about Cumberland',
        description: 'Essential details about Cumberland to help you plan your visit.',
        content: {
          sections: [
            {
              title: 'Location & Geography',
              icon: 'MapPin',
              content: [
                'Located in the heart of the region',
                'Surrounded by scenic mountains',
                'Four distinct seasons with moderate climate'
              ]
            },
            {
              title: 'Best Time to Visit',
              icon: 'Clock',
              content: [
                'Peak season: June to August',
                'Shoulder season: April-May, September-October',
                'Off-season: November to March'
              ]
            }
          ]
        }
      };

      const { error: contentError } = await supabase
        .from('content')
        .upsert(sampleContent);

      if (contentError) {
        console.error('Error seeding content:', contentError);
        return;
      }
      console.log('Content seeded successfully');
    }

    console.log('Data seeding completed successfully');
  } catch (error) {
    console.error('Unexpected error during seeding:', error);
  }
}

seedData();