// ✅ FINALIZED App.tsx
import React, { Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';

const LandingPage = React.lazy(() => import('./components/LandingPage'));
const Login = React.lazy(() => import('./components/Login'));
const Subscribe = React.lazy(() => import('./components/Subscribe'));
const AdminLayout = React.lazy(() => import('./components/admin/layout/AdminLayout'));
const Dashboard = React.lazy(() => import('./components/admin/Dashboard'));
const CitiesManager = React.lazy(() => import('./components/admin/CitiesManager'));
const CategoriesManager = React.lazy(() => import('./components/admin/CategoriesManager'));
const UsersManager = React.lazy(() => import('./components/admin/UsersManager'));
const RoleManager = React.lazy(() => import('./components/admin/RoleManager'));
const SubscriptionManager = React.lazy(() => import('./components/admin/SubscriptionManager'));
const UserLayout = React.lazy(() => import('./components/user/UserLayout'));
const ContentCategories = React.lazy(() => import('./components/ContentCategories'));
const CategoryPage = React.lazy(() => import('./components/CategoryPage'));

function LoadingSpinner() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
    </div>
  );
}

function ErrorBoundary({ children }: { children: React.ReactNode }) {
  const [hasError, setHasError] = React.useState(false);

  React.useEffect(() => {
    const handleError = () => setHasError(true);
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  if (hasError) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h2>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Reload page
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  if (isLoading) return <LoadingSpinner />;
  if (!user) return <Navigate to="/login" />;
  return <>{children}</>;
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading, isAdmin } = useAuth();
  if (isLoading) return <LoadingSpinner />;
  if (!user || !isAdmin) return <Navigate to="/" />;
  return <>{children}</>;
}

function App() {
  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadingSpinner />}>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/subscribe" element={<Subscribe />} />

          <Route
            path="/cities"
            element={
              <ProtectedRoute>
                <UserLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<ContentCategories />} />
            <Route path=":cityId" element={<ContentCategories />} />
            <Route path=":cityId/categories/:categoryId" element={<CategoryPage />} />
          </Route>

          <Route
            path="/admin"
            element={
              <AdminRoute>
                <AdminLayout />
              </AdminRoute>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="cities" element={<CitiesManager />} />
            <Route path="categories" element={<CategoriesManager />} />
            <Route path="users" element={<UsersManager />} />
            <Route path="roles" element={<RoleManager />} />
            <Route path="subscriptions" element={<SubscriptionManager />} />
          </Route>

          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Suspense>
    </ErrorBoundary>
  );
}

export default App;
