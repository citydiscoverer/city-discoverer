import React, { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, X, Check } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Role {
  id: string;
  name: string;
  permissions: {
    cities: Permission;
    categories: Permission;
    content: Permission;
    roles: Permission;
    users: Permission;
  };
}

interface Permission {
  create: boolean;
  read: boolean;
  update: boolean;
  delete: boolean;
}

interface AdminUser {
  id: string;
  email: string;
  role_id: string;
}

const RoleManager: React.FC = () => {
  const [roles, setRoles] = useState<Role[]>([]);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [isAddingRole, setIsAddingRole] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    fetchRoles();
    fetchUsers();
  }, []);

  const fetchRoles = async () => {
    const { data, error } = await supabase
      .from('admin_roles')
      .select('*')
      .order('name');
    
    if (error) {
      console.error('Error fetching roles:', error);
      return;
    }
    
    setRoles(data || []);
  };

  const fetchUsers = async () => {
    const { data, error } = await supabase
      .from('admin_users')
      .select(`
        id,
        user_id,
        role_id,
        auth.users (email)
      `);
    
    if (error) {
      console.error('Error fetching users:', error);
      return;
    }
    
    setUsers(data || []);
  };

  const handleAddRole = async () => {
    if (!newRoleName.trim()) return;

    const { error } = await supabase
      .from('admin_roles')
      .insert({
        name: newRoleName,
        permissions: {
          cities: { create: false, read: true, update: false, delete: false },
          categories: { create: false, read: true, update: false, delete: false },
          content: { create: false, read: true, update: false, delete: false },
          roles: { create: false, read: false, update: false, delete: false },
          users: { create: false, read: false, update: false, delete: false }
        }
      });

    if (error) {
      console.error('Error adding role:', error);
      return;
    }

    setSuccessMessage('Role added successfully');
    setNewRoleName('');
    setIsAddingRole(false);
    fetchRoles();
  };

  const handleUpdateRole = async (role: Role) => {
    const { error } = await supabase
      .from('admin_roles')
      .update(role)
      .eq('id', role.id);

    if (error) {
      console.error('Error updating role:', error);
      return;
    }

    setSuccessMessage('Role updated successfully');
    setEditingRole(null);
    fetchRoles();
  };

  const handleDeleteRole = async (id: string) => {
    if (!confirm('Are you sure you want to delete this role?')) return;

    const { error } = await supabase
      .from('admin_roles')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Error deleting role:', error);
      return;
    }

    setSuccessMessage('Role deleted successfully');
    fetchRoles();
  };

  const handleUpdateUserRole = async (userId: string, roleId: string) => {
    const { error } = await supabase
      .from('admin_users')
      .update({ role_id: roleId })
      .eq('user_id', userId);

    if (error) {
      console.error('Error updating user role:', error);
      return;
    }

    setSuccessMessage('User role updated successfully');
    fetchUsers();
  };

  return (
    <div className="space-y-8">
      {successMessage && (
        <div className="bg-green-100 text-green-700 p-4 rounded-md">
          {successMessage}
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Roles</h2>
          {!isAddingRole && (
            <button
              onClick={() => setIsAddingRole(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Role
            </button>
          )}
        </div>

        {isAddingRole && (
          <div className="mb-6 p-4 border rounded-md">
            <input
              type="text"
              className="w-full px-3 py-2 border rounded-md mb-4"
              placeholder="Role name"
              value={newRoleName}
              onChange={(e) => setNewRoleName(e.target.value)}
            />
            <div className="flex justify-end space-x-2">
              <button
                onClick={handleAddRole}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
              >
                <Check className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setIsAddingRole(false);
                  setNewRoleName('');
                }}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        <div className="space-y-4">
          {roles.map((role) => (
            <div key={role.id} className="border rounded-md p-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-medium">{role.name}</h3>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setEditingRole(role)}
                    className="p-2 text-blue-600 hover:text-blue-700"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  {role.name !== 'super_admin' && (
                    <button
                      onClick={() => handleDeleteRole(role.id)}
                      className="p-2 text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {editingRole?.id === role.id ? (
                <div className="space-y-4">
                  {Object.entries(role.permissions).map(([resource, perms]) => (
                    <div key={resource} className="space-y-2">
                      <h4 className="font-medium capitalize">{resource}</h4>
                      <div className="flex space-x-4">
                        {Object.entries(perms).map(([action, enabled]) => (
                          <label key={action} className="flex items-center">
                            <input
                              type="checkbox"
                              checked={enabled}
                              onChange={(e) => {
                                const newRole = {
                                  ...role,
                                  permissions: {
                                    ...role.permissions,
                                    [resource]: {
                                      ...role.permissions[resource as keyof Role['permissions']],
                                      [action]: e.target.checked
                                    }
                                  }
                                };
                                setEditingRole(newRole);
                              }}
                              className="mr-2"
                            />
                            <span className="capitalize">{action}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  ))}
                  <div className="flex justify-end space-x-2 mt-4">
                    <button
                      onClick={() => handleUpdateRole(editingRole)}
                      className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditingRole(null)}
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(role.permissions).map(([resource, perms]) => (
                    <div key={resource}>
                      <h4 className="font-medium capitalize mb-2">{resource}</h4>
                      <div className="text-sm text-gray-600">
                        {Object.entries(perms)
                          .filter(([, enabled]) => enabled)
                          .map(([action]) => (
                            <span key={action} className="mr-2 capitalize">
                              {action}
                            </span>
                          ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-6">User Roles</h2>
        <div className="space-y-4">
          {users.map((user: any) => (
            <div key={user.id} className="flex items-center justify-between p-4 border rounded-md">
              <span>{user.users.email}</span>
              <select
                value={user.role_id}
                onChange={(e) => handleUpdateUserRole(user.user_id, e.target.value)}
                className="ml-4 px-3 py-2 border rounded-md"
              >
                {roles.map((role) => (
                  <option key={role.id} value={role.id}>
                    {role.name}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RoleManager;