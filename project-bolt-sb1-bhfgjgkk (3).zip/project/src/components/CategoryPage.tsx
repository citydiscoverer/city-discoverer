import React, { useEffect, useState, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, ArrowLeftCircle, MapPin, Clock, Info, Star, Building, Music, Map, Sun, Users, History, Navigation, Camera, Shield, Utensils, Headphones, Calendar, Heart, ChevronDown } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface CityGuide {
  id: string;
  city_name: string;
  state: string;
  basic_info: any;
  local_attractions: any[];
  restaurants: any[];
  transportation: any;
  accommodations: any[];
  local_tips: any;
  history_culture: any;
  audio_guides: any;
  walking_tours: any[];
  seasonal_recommendations: any;
  architecture: any;
  etiquette: any;
}

const CATEGORIES = [
  { id: '1', title: 'Basic Information', icon: 'Info' },
  { id: '2', title: 'Local Attractions', icon: 'MapPin' },
  { id: '3', title: 'Restaurants & Dining', icon: 'Utensils' },
  { id: '4', title: 'Transportation', icon: 'Navigation' },
  { id: '5', title: 'Accommodations', icon: 'Building' },
  { id: '6', title: 'Local Tips & Secrets', icon: 'Star' },
  { id: '7', title: 'History & Culture', icon: 'History' },
  { id: '8', title: 'Audio & Interactive Guides', icon: 'Headphones' },
  { id: '9', title: 'Curated Walking Tours', icon: 'Map' },
  { id: '10', title: 'Seasonal Recommendations', icon: 'Sun' },
  { id: '11', title: 'Architectural Highlights', icon: 'Building' },
  { id: '12', title: 'Cultural Etiquette', icon: 'Shield' }
];

const CategoryPage: React.FC = () => {
  const { cityId, categoryId } = useParams();
  const navigate = useNavigate();
  const [cityGuide, setCityGuide] = useState<CityGuide | null>(null);
  const [loading, setLoading] = useState(true);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const fetchCityGuide = async () => {
      if (!cityId) return;

      const { data, error } = await supabase
        .from('city_guides')
        .select('*')
        .eq('id', cityId)
        .single();

      if (error) {
        console.error('Error fetching city guide:', error);
        setLoading(false);
        return;
      }

      setCityGuide(data);
      setLoading(false);
    };

    fetchCityGuide();

    // Set up real-time subscription
    const subscription = supabase
      .channel('city-guides-changes')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'city_guides', filter: `id=eq.${cityId}` },
        (payload) => {
          console.log('City guide change received:', payload);
          fetchCityGuide();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [cityId]);

  const currentCategoryIndex = CATEGORIES.findIndex(cat => cat.id === categoryId);
  const currentCategory = CATEGORIES[currentCategoryIndex];
  const prevCategory = currentCategoryIndex > 0 ? CATEGORIES[currentCategoryIndex - 1] : null;
  const nextCategory = currentCategoryIndex < CATEGORIES.length - 1 ? CATEGORIES[currentCategoryIndex + 1] : null;

  const navigateToCategory = (category: typeof CATEGORIES[0] | null) => {
    if (category && cityId) {
      navigate(`/cities/${cityId}/categories/${category.id}`);
      setIsDropdownOpen(false);
    }
  };

  const getCategoryContent = () => {
    if (!cityGuide || !categoryId) return null;

    const categoryMap: { [key: string]: any } = {
      '1': {
        title: 'Basic Information',
        data: cityGuide.basic_info,
        icon: 'Info'
      },
      '2': {
        title: 'Local Attractions',
        data: cityGuide.local_attractions,
        icon: 'MapPin'
      },
      '3': {
        title: 'Restaurants & Dining',
        data: cityGuide.restaurants,
        icon: 'Utensils'
      },
      '4': {
        title: 'Transportation',
        data: cityGuide.transportation,
        icon: 'Navigation'
      },
      '5': {
        title: 'Accommodations',
        data: cityGuide.accommodations,
        icon: 'Building'
      },
      '6': {
        title: 'Local Tips & Secrets',
        data: cityGuide.local_tips,
        icon: 'Star'
      },
      '7': {
        title: 'History & Culture',
        data: cityGuide.history_culture,
        icon: 'History'
      },
      '8': {
        title: 'Audio & Interactive Guides',
        data: cityGuide.audio_guides,
        icon: 'Headphones'
      },
      '9': {
        title: 'Curated Walking Tours',
        data: cityGuide.walking_tours,
        icon: 'Map'
      },
      '10': {
        title: 'Seasonal Recommendations',
        data: cityGuide.seasonal_recommendations,
        icon: 'Sun'
      },
      '11': {
        title: 'Architectural Highlights',
        data: cityGuide.architecture,
        icon: 'Building'
      },
      '12': {
        title: 'Cultural Etiquette',
        data: cityGuide.etiquette,
        icon: 'Shield'
      }
    };

    return categoryMap[categoryId];
  };

  const getIcon = (iconName: string) => {
    const icons = {
      MapPin: <MapPin className="w-5 h-5" />,
      Clock: <Clock className="w-5 h-5" />,
      Info: <Info className="w-5 h-5" />,
      Star: <Star className="w-5 h-5" />,
      Building: <Building className="w-5 h-5" />,
      Music: <Music className="w-5 h-5" />,
      Map: <Map className="w-5 h-5" />,
      Sun: <Sun className="w-5 h-5" />,
      Users: <Users className="w-5 h-5" />,
      History: <History className="w-5 h-5" />,
      Navigation: <Navigation className="w-5 h-5" />,
      Camera: <Camera className="w-5 h-5" />,
      Shield: <Shield className="w-5 h-5" />,
      Utensils: <Utensils className="w-5 h-5" />,
      Headphones: <Headphones className="w-5 h-5" />,
      Calendar: <Calendar className="w-5 h-5" />,
      Heart: <Heart className="w-5 h-5" />
    };
    return icons[iconName as keyof typeof icons] || <Info className="w-5 h-5" />;
  };

  const renderContent = (category: any) => {
    if (!category || !category.data) return null;

    if (Array.isArray(category.data)) {
      return (
        <div className="space-y-6">
          {category.data.map((item: any, index: number) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-lg font-medium text-gray-900 mb-2">{item.name}</h3>
              {item.description && (
                <p className="text-gray-600 mb-3">{item.description}</p>
              )}
              {item.tags && (
                <div className="flex flex-wrap gap-2">
                  {item.tags.map((tag: string, tagIndex: number) => (
                    <span key={tagIndex} className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                      {tag}
                    </span>
                  ))}
                </div>
              )}
              {item.specialties && (
                <div className="mt-3">
                  <h4 className="font-medium text-gray-700 mb-2">Specialties:</h4>
                  <ul className="list-disc pl-5 space-y-1">
                    {item.specialties.map((specialty: string, specIndex: number) => (
                      <li key={specIndex} className="text-gray-600">{specialty}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {Object.entries(category.data).map(([key, value]: [string, any]) => (
          <div key={key} className="flex flex-col sm:flex-row sm:items-start py-2">
            <span className="font-medium text-gray-700 min-w-[140px] sm:mb-0 mb-1">
              {key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, ' ')}:
            </span>
            <span className="text-gray-600">
              {Array.isArray(value) ? (
                <ul className="list-disc pl-4 space-y-1">
                  {value.map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              ) : (
                value
              )}
            </span>
          </div>
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const category = getCategoryContent();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Link 
          to={`/cities/${cityId}`}
          className="inline-flex items-center text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Categories
        </Link>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        {cityGuide && category ? (
          <>
            <div className="p-8 border-b border-gray-100">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center gap-3">
                  {getIcon(category.icon)}
                  <h1 className="text-3xl font-semibold text-gray-900">
                    {cityGuide.city_name}, {cityGuide.state} - {category.title}
                  </h1>
                </div>
                
                <div className="relative" ref={dropdownRef}>
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <span>Change Category</span>
                    <ChevronDown className={`ml-2 h-5 w-5 transition-transform ${isDropdownOpen ? 'transform rotate-180' : ''}`} />
                  </button>

                  {isDropdownOpen && (
                    <div 
                      className="absolute right-0 mt-2 w-64 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10 max-h-[calc(100vh-200px)] overflow-y-auto"
                      style={{
                        maxHeight: '400px',
                        overflowY: 'auto'
                      }}
                    >
                      <div className="py-1" role="menu">
                        {CATEGORIES.map((cat) => (
                          <button
                            key={cat.id}
                            onClick={() => navigateToCategory(cat)}
                            className={`w-full text-left px-4 py-2 text-sm ${
                              cat.id === categoryId
                                ? 'bg-gray-100 text-gray-900'
                                : 'text-gray-700 hover:bg-gray-50'
                            }`}
                            role="menuitem"
                          >
                            <div className="flex items-center">
                              {getIcon(cat.icon)}
                              <span className="ml-3">{cat.title}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="p-8">
              {renderContent(category)}
            </div>

            <div className="border-t border-gray-100 p-4">
              <div className="flex justify-between items-center">
                <button
                  onClick={() => navigateToCategory(prevCategory)}
                  className={`inline-flex items-center px-4 py-2 rounded-md ${
                    prevCategory
                      ? 'text-blue-600 hover:bg-blue-50'
                      : 'text-gray-300 cursor-not-allowed'
                  }`}
                  disabled={!prevCategory}
                >
                  <ArrowLeftCircle className="w-5 h-5 mr-2" />
                  {prevCategory?.title || 'Previous'}
                </button>

                <button
                  onClick={() => navigateToCategory(nextCategory)}
                  className={`inline-flex items-center px-4 py-2 rounded-md ${
                    nextCategory
                      ? 'text-blue-600 hover:bg-blue-50'
                      : 'text-gray-300 cursor-not-allowed'
                  }`}
                  disabled={!nextCategory}
                >
                  {nextCategory?.title || 'Next'}
                  <ArrowRight className="w-5 h-5 ml-2" />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center p-8 text-center">
            <Info className="w-6 h-6 text-gray-400 mb-2" />
            <p className="text-gray-600">Content for this category is not available.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryPage;