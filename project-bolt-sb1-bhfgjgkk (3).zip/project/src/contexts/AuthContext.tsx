// ✅ FINALIZED AuthContext.tsx
import React, { createContext, useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface User {
  id: string;
  email: string;
  metadata?: Record<string, any>;
  isAdmin?: boolean;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  isLoading: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const signIn = async (email: string, password: string) => {
    const res = await fetch('/api/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
      headers: { 'Content-Type': 'application/json' }
    });

    if (!res.ok) {
      throw new Error('Login failed');
    }

    const { user, token } = await res.json();
    setUser(user);
    setToken(token);
    localStorage.setItem('session_token', token);

    if (user.isAdmin) {
      navigate('/admin');
    } else {
      const initialCityId = user.metadata?.initial_city_id;
      navigate(initialCityId ? `/cities/${initialCityId}` : '/cities');
    }
  };

  const signOut = async () => {
    if (token) {
      await fetch('/api/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
    }
    setUser(null);
    setToken(null);
    localStorage.removeItem('session_token');
    navigate('/');
  };

  const fetchCurrentUser = async (existingToken: string) => {
    const res = await fetch('/api/user', {
      headers: { Authorization: `Bearer ${existingToken}` }
    });

    if (res.ok) {
      const user = await res.json();
      setUser(user);
      return user;
    } else {
      setUser(null);
      return null;
    }
  };

  useEffect(() => {
    const restoreSession = async () => {
      const savedToken = localStorage.getItem('session_token');
      if (!savedToken) {
        setIsLoading(false);
        return;
      }

      setToken(savedToken);
      const user = await fetchCurrentUser(savedToken);

      if (user) {
        if (user.isAdmin) {
          navigate('/admin');
        } else {
          const cityId = user.metadata?.initial_city_id;
          navigate(cityId ? `/cities/${cityId}` : '/cities');
        }
      }

      setIsLoading(false);
    };

    restoreSession();
  }, []);

  return (
    <AuthContext.Provider value={{ user, token, signIn, signOut, isLoading, isAdmin: !!user?.isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside AuthProvider');
  return context;
}
