/*
  # Add Little Rock city guide data

  1. New Data
    - Adds Little Rock, AR to the city_guides table
    - Includes comprehensive city information:
      - Basic information
      - Local attractions
      - Restaurants
      - Transportation
      - Accommodations
      - Local tips
      - History and culture
      - Audio guides
      - Walking tours
      - Seasonal recommendations
      - Architecture
      - Etiquette
*/

INSERT INTO city_guides (
  city_name,
  state,
  basic_info,
  local_attractions,
  restaurants,
  transportation,
  accommodations,
  local_tips,
  history_culture,
  audio_guides,
  walking_tours,
  seasonal_recommendations,
  architecture,
  etiquette
) VALUES (
  'Little Rock',
  'AR',
  '{
    "population": "204,647",
    "year_estimate": 2025,
    "founded": "1820",
    "geography": "South bank of the Arkansas River near the foothills of the Ouachita Mountains",
    "region": "Central Arkansas",
    "language": "English",
    "currency": "USD",
    "coordinates": [34.7465, -92.2896]
  }',
  '[
    {
      "name": "Little Rock Central High School National Historic Site",
      "description": "A pivotal Civil Rights Movement site commemorating the Little Rock Nine.",
      "tags": ["Civil Rights", "History", "Education"]
    },
    {
      "name": "Clinton Presidential Center",
      "description": "Features presidential exhibits, archives, and a full-scale Oval Office replica.",
      "tags": ["Museum", "Presidential", "History"]
    },
    {
      "name": "Pinnacle Mountain State Park",
      "description": "Offers hiking trails with views of the Arkansas River Valley.",
      "tags": ["Hiking", "Nature", "Panoramic Views"]
    },
    {
      "name": "The Big Dam Bridge",
      "description": "Longest pedestrian/bike bridge in North America, great for exercise and views.",
      "tags": ["Bridge", "Walking", "Cycling"]
    },
    {
      "name": "River Market District",
      "description": "Shops, restaurants, and public markets in a lively urban setting.",
      "tags": ["Market", "Dining", "Shopping"]
    },
    {
      "name": "The Old Mill",
      "description": "Recreation of a historic grist mill featured in ''Gone with the Wind.''",
      "tags": ["Film", "Scenic", "Photography"]
    }
  ]',
  '[
    {
      "name": "Lassis Inn",
      "cuisine": "Southern, Seafood",
      "price_range": "$",
      "specialties": ["Fried catfish", "Buffalo fish ribs"]
    },
    {
      "name": "The Pantry",
      "cuisine": "European (Czech, German)",
      "price_range": "$$",
      "specialties": ["Schnitzel", "Bratwurst"]
    },
    {
      "name": "The Root Café",
      "cuisine": "Farm-to-table, American",
      "price_range": "$$",
      "specialties": ["Locally sourced dishes", "Vegetarian options"]
    },
    {
      "name": "Whole Hog Café",
      "cuisine": "Barbecue",
      "price_range": "$$",
      "specialties": ["Pulled pork", "Ribs", "Variety of sauces"]
    },
    {
      "name": "Bruno''s Little Italy",
      "cuisine": "Italian",
      "price_range": "$$",
      "specialties": ["Pasta dishes", "Traditional Italian fare"]
    }
  ]',
  '{
    "transit_agency": "Rock Region METRO",
    "services": ["Bus", "Streetcar"],
    "streetcar_route": "3.4-mile route connecting Little Rock and North Little Rock",
    "highways": ["I-30", "I-40"]
  }',
  '[
    {
      "name": "Little Rock Marriott",
      "type": "Hotel",
      "features": ["Downtown location", "Next to River Market District"]
    },
    {
      "name": "The Empress of Little Rock",
      "type": "Bed & Breakfast",
      "features": ["Victorian mansion", "Historic setting"]
    },
    {
      "name": "Comfort Inn & Suites Presidential",
      "type": "Hotel",
      "features": ["Downtown proximity", "Complimentary breakfast"]
    }
  ]',
  '{
    "cheese_dip": "Little Rock is considered the Cheese Dip Capital—try Mexico Chiquito or Dizzy''s.",
    "riverfront_park": "Great for walking, public art, and riverside relaxation.",
    "hillcrest": "Trendy historic district with local shops and dining."
  }',
  '{
    "civil_rights": "Central High School was key in 1957 desegregation events.",
    "clinton_library": "A major archive of Bill Clinton''s presidency.",
    "historic_arkansas_museum": "Exhibits on frontier life and Arkansas culture."
  }',
  '{
    "civil_rights_tour": "Audio tour with 35+ Civil Rights sites.",
    "political_tour": "Self-guided political history tour of 23 sites.",
    "museum_of_fine_arts": "Audio guides for current exhibitions."
  }',
  '[
    {
      "name": "Downtown Little Rock Walking Tour",
      "route": "Covers historic and cultural downtown highlights.",
      "points_of_interest": ["State Capitol", "River Market", "Historic Museums"],
      "duration_hours": 1.5
    },
    {
      "name": "GPSmyCity Self-Guided Tours",
      "route": "Various themed tours with maps and descriptions.",
      "points_of_interest": ["Government sites", "Local culture"],
      "duration_hours": 1.5
    }
  ]',
  '{
    "spring": "Best time for River Trail walks and flowers.",
    "summer": "Live music and festivals in River Market.",
    "fall": "Foliage views at Pinnacle Mountain.",
    "winter": "Holiday events and indoor cultural activities."
  }',
  '{
    "notables": [
      {
        "name": "Arkansas State Capitol",
        "style": "Neoclassical",
        "note": "Modeled after the U.S. Capitol."
      },
      {
        "name": "Old State House Museum",
        "style": "Greek Revival",
        "note": "Oldest state capitol west of the Mississippi."
      },
      {
        "name": "Quapaw Quarter",
        "style": "Various historic styles",
        "note": "Notable for preserved historic homes and buildings."
      }
    ]
  }',
  '{
    "hospitality": "Southern manners are important—be polite and engage in small talk.",
    "tipping": "15-20% is standard for restaurants and services.",
    "dress_code": "Casual is fine, with business casual for more formal places."
  }'
);