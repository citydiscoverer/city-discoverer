/*
  # Set up subscriber user and fix policies

  1. Changes
    - Set up felixabayomi@icloud.com as a subscriber
    - Grant access to Cumberland and Wiley Ford
    - Fix policy recursion issues
    
  2. Security
    - Enable RLS on affected tables
    - Add appropriate policies for subscribers
*/

-- First ensure both cities exist in cities table
INSERT INTO cities (name)
VALUES 
  ('Cumberland'),
  ('Wiley Ford')
ON CONFLICT (name) DO NOTHING;

-- Create city guides if they don't exist
INSERT INTO city_guides (city_name, state, basic_info, local_attractions, restaurants, transportation, accommodations, local_tips, history_culture, audio_guides, walking_tours, seasonal_recommendations, architecture, etiquette)
VALUES 
  ('Cumberland', 'MD', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}'),
  ('Wiley Ford', 'WV', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '[]', '{}', '{}', '{}', '{}')
ON CONFLICT ON CONSTRAINT unique_city_state DO NOTHING;

-- Create a special tier for legacy users if it doesn't exist
INSERT INTO subscription_tiers (name, city_limit, price)
VALUES ('Legacy User', 2, 0)
ON CONFLICT (name) DO NOTHING;

-- Set up user subscription and cities
DO $$
DECLARE
  v_user_id uuid;
  v_tier_id uuid;
  v_cumberland_id uuid;
  v_wiley_ford_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'felixabayomi@icloud.com';

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User not found with email felixabayomi@icloud.com';
  END IF;

  -- Get tier ID
  SELECT id INTO v_tier_id
  FROM subscription_tiers
  WHERE name = 'Legacy User';

  -- Get city IDs
  SELECT id INTO v_cumberland_id
  FROM cities
  WHERE name = 'Cumberland';

  SELECT id INTO v_wiley_ford_id
  FROM cities
  WHERE name = 'Wiley Ford';

  -- Update user metadata to ensure correct role
  UPDATE auth.users
  SET raw_user_meta_data = jsonb_build_object(
    'role', 'subscriber',
    'initial_city_id', v_cumberland_id,
    'city_name', 'Cumberland',
    'state', 'MD'
  )
  WHERE id = v_user_id;

  -- Set up subscription
  INSERT INTO user_subscriptions (user_id, tier_id, active, expires_at)
  VALUES (v_user_id, v_tier_id, true, '2099-12-31 23:59:59'::timestamptz)
  ON CONFLICT (user_id) 
  DO UPDATE SET
    tier_id = EXCLUDED.tier_id,
    active = EXCLUDED.active,
    expires_at = EXCLUDED.expires_at;

  -- Add city access
  INSERT INTO user_cities (user_id, city_id)
  VALUES 
    (v_user_id, v_cumberland_id),
    (v_user_id, v_wiley_ford_id)
  ON CONFLICT (user_id, city_id) DO NOTHING;

END $$;

-- Fix policy recursion issues
DROP POLICY IF EXISTS "admin_roles_manage" ON admin_roles;
DROP POLICY IF EXISTS "admin_roles_read" ON admin_roles;

-- Create non-recursive policies
CREATE POLICY "admin_roles_read"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "admin_roles_manage"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);