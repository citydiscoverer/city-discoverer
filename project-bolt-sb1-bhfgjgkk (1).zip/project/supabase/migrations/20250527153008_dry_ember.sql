/*
  # Fix admin policies recursion

  1. Changes
    - Drop existing problematic policies
    - Create simplified non-recursive policies for admin_users and admin_roles
    - Ensure proper access control while avoiding circular dependencies
  
  2. Security
    - Maintain proper access control for super admins
    - Allow users to read their own records
    - Prevent unauthorized access
*/

-- Drop existing policies that may cause recursion
DROP POLICY IF EXISTS "Super admins can manage admin users" ON admin_users;
DROP POLICY IF EXISTS "Users can read own admin record" ON admin_users;
DROP POLICY IF EXISTS "Manage admin roles" ON admin_roles;
DROP POLICY IF EXISTS "Read admin roles base" ON admin_roles;

-- Create new simplified policies for admin_users
CREATE POLICY "Users can read own admin record"
ON admin_users
FOR SELECT 
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Super admins can manage admin users"
ON admin_users
FOR ALL 
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM admin_roles
    WHERE id IN (
      SELECT role_id 
      FROM admin_users au 
      WHERE au.user_id = auth.uid()
    )
    AND name = 'super_admin'
  )
);

-- Create new simplified policies for admin_roles
CREATE POLICY "Read admin roles base"
ON admin_roles
FOR SELECT 
TO authenticated
USING (true);

CREATE POLICY "Manage admin roles"
ON admin_roles
FOR ALL 
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM admin_roles
    WHERE id IN (
      SELECT role_id 
      FROM admin_users 
      WHERE user_id = auth.uid()
    )
    AND name = 'super_admin'
  )
);