/*
  # Create subscription management tables

  1. New Tables
    - subscription_tiers
      - id (uuid, primary key)
      - name (text)
      - max_cities (integer)
      - price (numeric)
      - created_at (timestamp)
    
    - user_subscriptions
      - id (uuid, primary key)
      - user_id (uuid, foreign key to auth.users)
      - subscription_tier_id (uuid, foreign key to subscription_tiers)
      - created_at (timestamp)
    
    - user_cities
      - id (uuid, primary key)
      - user_id (uuid, foreign key to auth.users)
      - city_id (uuid, foreign key to cities)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read their own data
    - Add policies for admins to manage all data
*/

-- Create subscription_tiers table
CREATE TABLE IF NOT EXISTS subscription_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  max_cities integer NOT NULL,
  price numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE subscription_tiers ENABLE ROW LEVEL SECURITY;

-- Create user_subscriptions table
CREATE TABLE IF NOT EXISTS user_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  subscription_tier_id uuid REFERENCES subscription_tiers(id) ON DELETE RESTRICT,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;

-- Create user_cities table
CREATE TABLE IF NOT EXISTS user_cities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  city_id uuid REFERENCES cities(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, city_id)
);

ALTER TABLE user_cities ENABLE ROW LEVEL SECURITY;

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_user_id ON user_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_cities_user_id ON user_cities(user_id);
CREATE INDEX IF NOT EXISTS idx_user_cities_city_id ON user_cities(city_id);

-- RLS Policies for subscription_tiers
CREATE POLICY "Anyone can read subscription tiers"
  ON subscription_tiers
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admins can modify subscription tiers"
  ON subscription_tiers
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      JOIN admin_roles ar ON au.role_id = ar.id
      WHERE au.user_id = auth.uid()
      AND ar.name = 'super_admin'
    )
  );

-- RLS Policies for user_subscriptions
CREATE POLICY "Users can read their own subscription"
  ON user_subscriptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Only admins can modify subscriptions"
  ON user_subscriptions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      JOIN admin_roles ar ON au.role_id = ar.id
      WHERE au.user_id = auth.uid()
      AND ar.name = 'super_admin'
    )
  );

-- RLS Policies for user_cities
CREATE POLICY "Users can read their own cities"
  ON user_cities
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Only admins can modify user cities"
  ON user_cities
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      JOIN admin_roles ar ON au.role_id = ar.id
      WHERE au.user_id = auth.uid()
      AND ar.name = 'super_admin'
    )
  );

-- Function to check if a user has access to a city
CREATE OR REPLACE FUNCTION public.has_city_access(city_uuid uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_cities uc
    WHERE uc.user_id = auth.uid()
    AND uc.city_id = city_uuid
  );
END;
$$;