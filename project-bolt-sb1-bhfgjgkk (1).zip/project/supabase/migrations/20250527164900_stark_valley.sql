/*
  # Fix admin role policies

  1. Changes
    - Drop all existing problematic policies
    - Create new non-recursive policies for admin roles
    - Simplify policy logic to prevent recursion
    
  2. Security
    - Maintains proper access control
    - Eliminates circular dependencies
    - Preserves super admin privileges
*/

-- Drop all existing policies to start fresh
DROP POLICY IF EXISTS "admin_roles_read" ON admin_roles;
DROP POLICY IF EXISTS "admin_roles_manage" ON admin_roles;
DROP POLICY IF EXISTS "read_roles" ON admin_roles;
DROP POLICY IF EXISTS "manage_roles" ON admin_roles;

-- Create new simplified read policy
CREATE POLICY "admin_roles_read"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

-- Create new simplified management policy
CREATE POLICY "admin_roles_manage"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id 
      FROM admin_roles 
      WHERE name = 'super_admin'
    )
  )
);