/*
  # Update Schema for City Guides

  1. New Tables
    - `city_guides`
      - `id` (uuid, primary key)
      - `city_name` (text)
      - `state` (text)
      - `basic_info` (jsonb)
      - `local_attractions` (jsonb)
      - `restaurants` (jsonb)
      - `transportation` (jsonb)
      - `accommodations` (jsonb)
      - `local_tips` (jsonb)
      - `history_culture` (jsonb)
      - `audio_guides` (jsonb)
      - `walking_tours` (jsonb)
      - `seasonal_recommendations` (jsonb)
      - `architecture` (jsonb)
      - `etiquette` (jsonb)

  2. Data Migration
    - Create new table structure
    - Migrate existing data to new format
    - Add RLS policies

  3. Security
    - Enable RLS
    - Add policies for public read access
    - Add policies for authenticated management
*/

-- Create new city_guides table
CREATE TABLE IF NOT EXISTS city_guides (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  city_name text NOT NULL,
  state text NOT NULL,
  basic_info jsonb NOT NULL DEFAULT '{}',
  local_attractions jsonb NOT NULL DEFAULT '[]',
  restaurants jsonb NOT NULL DEFAULT '[]',
  transportation jsonb NOT NULL DEFAULT '{}',
  accommodations jsonb NOT NULL DEFAULT '[]',
  local_tips jsonb NOT NULL DEFAULT '{}',
  history_culture jsonb NOT NULL DEFAULT '{}',
  audio_guides jsonb NOT NULL DEFAULT '{}',
  walking_tours jsonb NOT NULL DEFAULT '[]',
  seasonal_recommendations jsonb NOT NULL DEFAULT '{}',
  architecture jsonb NOT NULL DEFAULT '{}',
  etiquette jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add unique constraint on city_name and state
ALTER TABLE city_guides ADD CONSTRAINT unique_city_state UNIQUE (city_name, state);

-- Enable RLS
ALTER TABLE city_guides ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access to city guides"
  ON city_guides FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow authenticated users to manage city guides"
  ON city_guides FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create updated_at trigger
CREATE TRIGGER update_city_guides_updated_at
    BEFORE UPDATE ON city_guides
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Insert Wiley Ford data
INSERT INTO city_guides (
  city_name,
  state,
  basic_info,
  local_attractions,
  restaurants,
  transportation,
  accommodations,
  local_tips,
  history_culture,
  audio_guides,
  walking_tours,
  seasonal_recommendations,
  architecture,
  etiquette
) VALUES (
  'Wiley Ford',
  'WV',
  '{
    "population": "588",
    "year_estimate": 2023,
    "founded": "Early 20th century",
    "geography": "Small unincorporated community along the Potomac River, adjacent to Cumberland, MD",
    "region": "Appalachian Mountains, Eastern Panhandle of West Virginia",
    "language": "English",
    "currency": "USD",
    "coordinates": [39.6265, -78.7756]
  }',
  '[
    {
      "name": "Knobley Tunnel Trail",
      "description": "A peaceful rail trail through wooded areas.",
      "tags": ["Hiking", "Nature", "Rail Trail"]
    },
    {
      "name": "Helmstetter''s Curve",
      "description": "A historic railroad curve popular with photographers.",
      "tags": ["Historic", "Photography Spot"]
    },
    {
      "name": "Brush Tunnel",
      "description": "Historic tunnel for trains and cyclists on the GAP.",
      "tags": ["Biking", "History"]
    }
  ]',
  '[
    {
      "name": "Hummingbird Café",
      "cuisine": "American/Diner",
      "price_range": "$",
      "specialties": ["Breakfast platters", "Homemade desserts"]
    },
    {
      "name": "Oscar''s Restaurant",
      "cuisine": "American",
      "price_range": "$",
      "specialties": ["Country-style breakfast and lunch"]
    },
    {
      "name": "Patrick''s Restaurant",
      "cuisine": "American",
      "price_range": "$$",
      "specialties": ["Burgers", "Fish sandwiches"]
    }
  ]',
  '{
    "airport": "Greater Cumberland Regional Airport (CBE)",
    "transit": {
      "provider": "Potomac Valley Transit Authority (PVTA)",
      "notable_route": "Queen City Commuter"
    }
  }',
  '[
    {
      "name": "Comfort Inn & Suites LaVale - Cumberland",
      "type": "Hotel",
      "features": ["Breakfast", "Fitness center", "Proximity to Wiley Ford"]
    },
    {
      "name": "Cumberland Inn & Spa",
      "type": "Boutique Inn",
      "features": ["Spa services", "Historic setting", "Walkable location"]
    }
  ]',
  '{
    "airport_cafe": "Hummingbird Café is a hidden breakfast gem.",
    "scenic_views": "Helmstetter''s Curve at golden hour is ideal for photos.",
    "wildlife": "River trails are great for spring birdwatching."
  }',
  '{
    "background": "Named for Mr. Wiley, an early settler.",
    "significance": "Developed due to B&O Railroad and Potomac River trade."
  }',
  '{
    "description": "No local guides, but Cumberland offers self-guided walking tours.",
    "source": "passagesofthepotomac.org"
  }',
  '[
    {
      "name": "Potomac River Trail Loop",
      "points": ["Knobley Tunnel", "Brush Tunnel", "Helmstetter''s Curve"],
      "distance_miles": 4,
      "duration_hours": 2
    }
  ]',
  '{
    "spring": "Birdwatching and hiking.",
    "summer": "Shaded trails and river spots.",
    "fall": "Foliage views at Helmstetter''s Curve.",
    "winter": "Snow-covered trail walks."
  }',
  '{
    "residential_note": "Wiley Ford is mostly residential.",
    "nearby": [
      {
        "name": "Allegany County Courthouse",
        "style": "Romanesque Revival",
        "year": 1893
      },
      {
        "name": "Downtown Cumberland",
        "style": "Victorian & early 20th-century facades"
      }
    ]
  }',
  '{
    "customs": "Friendly greetings appreciated.",
    "norms": "Respect private property.",
    "tips": "Support and tip local businesses generously."
  }'
);