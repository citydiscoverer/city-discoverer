/*
  # Add City Constraints and Legacy Data

  1. Schema Changes
    - Add unique constraint for city name and state combination
    - Add check constraint for state format
  
  2. Data
    - Insert initial cities
    - Create legacy user tier
    - Set up user subscriptions and city access
*/

-- Add unique constraint for city name and state
ALTER TABLE cities ADD CONSTRAINT unique_city_name_state UNIQUE (name, state);

-- Add check constraint for state format (2 uppercase letters)
ALTER TABLE cities ADD CONSTRAINT valid_state_format CHECK (state ~ '^[A-Z]{2}$');

-- Insert initial cities with proper state format
INSERT INTO cities (name, state)
VALUES 
  ('Cumberland', 'MD'),
  ('Wiley Ford', 'WV')
ON CONFLICT (name, state) DO NOTHING;

-- Create legacy user tier
INSERT INTO subscription_tiers (name, city_limit, price)
VALUES ('Legacy User', 2, 0)
ON CONFLICT (name) DO NOTHING;

-- Set up user subscription and city access
DO $$
DECLARE
  v_user_id uuid;
  v_tier_id uuid;
  v_cumberland_id uuid;
  v_wiley_ford_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id 
  FROM auth.users 
  WHERE email = 'felixabayomii@icloud.com';

  -- Get tier ID
  SELECT id INTO v_tier_id
  FROM subscription_tiers
  WHERE name = 'Legacy User';

  -- Get city IDs
  SELECT id INTO v_cumberland_id
  FROM cities
  WHERE name = 'Cumberland' AND state = 'MD';

  SELECT id INTO v_wiley_ford_id
  FROM cities
  WHERE name = 'Wiley Ford' AND state = 'WV';

  -- Create user subscription if user exists
  IF v_user_id IS NOT NULL THEN
    INSERT INTO user_subscriptions (user_id, tier_id, active, expires_at)
    VALUES (
      v_user_id,
      v_tier_id,
      true,
      '2099-12-31 23:59:59'::timestamptz
    )
    ON CONFLICT (user_id) 
    DO UPDATE SET 
      tier_id = EXCLUDED.tier_id,
      active = EXCLUDED.active,
      expires_at = EXCLUDED.expires_at;

    -- Add city access
    INSERT INTO user_cities (user_id, city_id)
    VALUES 
      (v_user_id, v_cumberland_id),
      (v_user_id, v_wiley_ford_id)
    ON CONFLICT (user_id, city_id) DO NOTHING;
  END IF;
END $$;