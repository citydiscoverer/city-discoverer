/*
  # Seed Database with Initial Data

  1. Categories
    - Insert 12 predefined categories
  2. Content
    - Create placeholder content for each city-category combination
*/

-- Insert categories
INSERT INTO categories (name)
VALUES 
  ('Basic Information'),
  ('Local Attractions'),
  ('Restaurants & Dining'),
  ('Transportation'),
  ('Accommodations'),
  ('Local Tips & Secrets'),
  ('History & Culture'),
  ('Audio & Interactive Guides'),
  ('Curated Walking Tours'),
  ('Seasonal Recommendations'),
  ('Architectural Highlights'),
  ('Cultural Etiquette')
ON CONFLICT (name) DO NOTHING;

-- Function to create placeholder content
CREATE OR REPLACE FUNCTION create_placeholder_content()
RETURNS void AS $$
DECLARE
    city_rec RECORD;
    category_rec RECORD;
    content_json jsonb;
BEGIN
    FOR city_rec IN SELECT id, name FROM cities LOOP
        FOR category_rec IN SELECT id, name FROM categories LOOP
            -- Create basic content structure
            content_json := jsonb_build_object(
                'sections', jsonb_build_array(
                    jsonb_build_object(
                        'title', 'Coming Soon',
                        'icon', 'Info',
                        'content', jsonb_build_array(
                            format('Content for %s in %s will be available soon.', 
                                  category_rec.name, city_rec.name)
                        )
                    )
                )
            );

            -- Insert content
            INSERT INTO content (
                city_id,
                category_id,
                title,
                description,
                content
            )
            VALUES (
                city_rec.id,
                category_rec.id,
                format('%s - %s', city_rec.name, category_rec.name),
                format('Information about %s for %s', category_rec.name, city_rec.name),
                content_json
            )
            ON CONFLICT (city_id, category_id) DO NOTHING;
        END LOOP;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Add unique constraint to prevent duplicate city-category combinations
ALTER TABLE content ADD CONSTRAINT unique_city_category UNIQUE (city_id, category_id);

-- Create the placeholder content
SELECT create_placeholder_content();

-- Clean up the temporary function
DROP FUNCTION create_placeholder_content();