INSERT INTO city_guides (
  city_name,
  state,
  basic_info,
  local_attractions,
  restaurants,
  transportation,
  accommodations,
  local_tips,
  history_culture,
  audio_guides,
  walking_tours,
  seasonal_recommendations,
  architecture,
  etiquette
) VALUES (
  'Lexington',
  'KY',
  '{
    "population": "318,505",
    "year_estimate": 2025,
    "founded": "1775; chartered in 1782",
    "geography": "Located in the heart of Kentucky''s Bluegrass Region, characterized by gently rolling plateaus and fertile soil",
    "region": "Bluegrass Region, Central Kentucky",
    "language": "English",
    "currency": "USD",
    "coordinates": [38.047989, -84.501640]
  }',
  '[
    {
      "name": "Keeneland Race Course",
      "description": "Historic thoroughbred racetrack offering live races and behind-the-scenes tours.",
      "tags": ["Horse Racing", "Historic", "Equestrian"]
    },
    {
      "name": "Kentucky Horse Park",
      "description": "Equestrian theme park with museums, shows, and interactive exhibits.",
      "tags": ["Equestrian", "Museum", "Family-Friendly"]
    },
    {
      "name": "Mary Todd Lincoln House",
      "description": "Childhood home of Abraham Lincoln''s wife, open for guided tours.",
      "tags": ["Historic", "Presidential", "Tours"]
    },
    {
      "name": "Distillery District",
      "description": "Revitalized area with craft breweries, distilleries, and eateries.",
      "tags": ["Craft Beer", "Dining", "Local"]
    },
    {
      "name": "Ashland, The Henry Clay Estate",
      "description": "Home of Henry Clay featuring tours and formal gardens.",
      "tags": ["Historic Home", "Politics", "Gardens"]
    }
  ]',
  '[
    {
      "name": "Dudley''s on Short",
      "cuisine": "Southern-inspired American",
      "price_range": "$$$",
      "specialties": ["Deviled eggs", "Bacon beignets"]
    },
    {
      "name": "Pearl''s",
      "cuisine": "Bagels by day, pizza and wine by night",
      "price_range": "$$",
      "specialties": ["Wood-fired pizza", "Natural wines"]
    },
    {
      "name": "Carson''s Food & Drink",
      "cuisine": "American",
      "price_range": "$$",
      "specialties": ["Bourbon-infused dishes", "Upscale comfort food"]
    },
    {
      "name": "Blue Door Smokehouse",
      "cuisine": "Barbecue",
      "price_range": "$",
      "specialties": ["Brisket", "Pulled pork"]
    },
    {
      "name": "Corto Lima",
      "cuisine": "Latin-inspired",
      "price_range": "$$",
      "specialties": ["Tacos", "Ceviche"]
    }
  ]',
  '{
    "transit_agency": "Lextran",
    "services": ["Bus"],
    "airport": "Blue Grass Airport (LEX)",
    "rideshare": ["Uber", "Lyft"],
    "pedestrian_friendly": true
  }',
  '[
    {
      "name": "21c Museum Hotel",
      "type": "Boutique Hotel and Contemporary Art Museum",
      "features": ["Art installations", "Upscale dining"]
    },
    {
      "name": "The Campbell House",
      "type": "Historic Hotel",
      "features": ["Southern charm", "Modern amenities"]
    },
    {
      "name": "Origin Hotel Lexington",
      "type": "Modern Boutique Hotel",
      "features": ["Locally inspired design", "On-site dining"]
    },
    {
      "name": "Hyatt Regency Lexington",
      "type": "Full-Service Hotel",
      "features": ["Connected to Rupp Arena", "Downtown location"]
    },
    {
      "name": "Staybridge Suites Lexington",
      "type": "Extended Stay Hotel",
      "features": ["Suites with kitchens", "Complimentary breakfast"]
    }
  ]',
  '{
    "tuk_tuk": "Try Tuk Tuk Snack Shop for hidden Southeast Asian flavors.",
    "granddam": "Cocktail bar with creative plates in a chic setting.",
    "ale8": "Enjoy Kentucky''s regional Ale-8-One soda, often mixed with bourbon.",
    "farmers_market": "Weekend Lexington Farmers'' Market is great for local crafts and produce.",
    "the_square": "Victorian-era buildings with art galleries and shops downtown."
  }',
  '{
    "founding": "Named after the Battle of Lexington, founded in 1775.",
    "transylvania_u": "First university west of the Allegheny Mountains, founded in 1780.",
    "athens_of_the_west": "Lexington was nicknamed for its 19th-century cultural prominence.",
    "henry_clay": "Home of renowned statesman Henry Clay."
  }',
  '{
    "library_tours": "Lexington Public Library provides downtown-focused audio walking tours.",
    "voicemap": "VoiceMap app offers immersive self-guided audio tours.",
    "bites_bluegrass": "Combines food tastings with historical stories in guided tours."
  }',
  '[
    {
      "name": "Downtown Historic Sites Tour",
      "route": "A 1.1-mile loop covering key downtown landmarks.",
      "points_of_interest": ["Courthouse", "Cheapside Park", "Opera House"],
      "duration_hours": 1.5
    },
    {
      "name": "Historic Homes Tour",
      "route": "Showcases Mary Todd Lincoln House and Hunt-Morgan House.",
      "points_of_interest": ["Mary Todd Lincoln House", "Hunt-Morgan House"],
      "duration_hours": 1.5
    },
    {
      "name": "Distillery District Stroll",
      "route": "Warehouse district filled with breweries and food.",
      "points_of_interest": ["Barrel House", "Elkhorn Tavern"],
      "duration_hours": 1
    }
  ]',
  '{
    "spring": "Attend Keeneland races and enjoy the blooming gardens.",
    "summer": "Concerts and festivals take over downtown.",
    "fall": "Colorful foliage and Keeneland Fall Meet make it ideal for a visit.",
    "winter": "Experience Southern Lights and holiday events at Shaker Village."
  }',
  '{
    "notables": [
      {
        "name": "First National Building",
        "style": "Skyscraper",
        "note": "Lexington''s first skyscraper, now 21c Museum Hotel."
      },
      {
        "name": "Lexington Opera House",
        "style": "19th-century",
        "note": "Restored theater with a full performance schedule."
      },
      {
        "name": "Victorian Square",
        "style": "Victorian",
        "note": "Restored 19th-century buildings now home to shops and art."
      }
    ]
  }',
  '{
    "hospitality": "Southern politeness is the norm—greet people warmly.",
    "tipping": "15–20% is customary for services.",
    "dress_code": "Casual wear is fine, business casual recommended for upscale venues."
  }'
);