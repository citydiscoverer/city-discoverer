/*
  # Fix admin roles RLS policies

  1. Changes
    - Remove recursive policy on admin_roles table
    - Add new policy for super admins using a direct check
    - Add policy for admins to read roles
  
  2. Security
    - Enable RLS on admin_roles table
    - Add policies for:
      - Super admins to manage all roles
      - All admins to read roles
*/

-- First, drop the existing policy that's causing recursion
DROP POLICY IF EXISTS "Super admins can manage roles" ON admin_roles;

-- Create new policies without recursion
CREATE POLICY "Super admins can manage roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);

-- Add a read policy for all admin users
CREATE POLICY "Admins can read roles"
ON admin_roles
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE user_id = auth.uid()
  )
);