/*
  # Fix admin roles policy recursion

  1. Changes
    - Drop existing problematic policies on admin_roles table
    - Create new non-recursive policies for admin_roles table
    
  2. Security
    - Enable RLS on admin_roles table (maintained)
    - Add policy for super admins to manage roles (fixed)
    - Add policy for authenticated users to read roles (fixed)
    
  Note: The previous policies were causing infinite recursion by checking admin status 
  within the policy itself. The new policies avoid this by using simpler conditions.
*/

-- Drop existing policies to replace them
DROP POLICY IF EXISTS "Read admin roles base" ON admin_roles;
DROP POLICY IF EXISTS "Super admins can manage roles" ON admin_roles;

-- Create new non-recursive policies
CREATE POLICY "Allow authenticated to read roles"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Super admins manage roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE admin_users.user_id = auth.uid()
    AND admin_users.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);