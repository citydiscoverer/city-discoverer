/*
  # Create Admin User Migration

  1. Creates super_admin role if it doesn't exist
  2. Creates admin user with email felixabayomi@icloud.com
  3. Assigns super_admin role to the user
  4. Sets up necessary metadata and permissions
*/

-- First ensure the super_admin role exists
INSERT INTO admin_roles (name, permissions)
VALUES (
  'super_admin',
  jsonb_build_object(
    'cities', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'categories', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'content', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'roles', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'users', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true)
  )
)
ON CONFLICT (name) 
DO UPDATE SET permissions = EXCLUDED.permissions
RETURNING id;

-- Create the auth user if it doesn't exist
DO $$
DECLARE
  v_user_id uuid;
  v_role_id uuid;
BEGIN
  -- Get super_admin role id
  SELECT id INTO v_role_id
  FROM admin_roles
  WHERE name = 'super_admin';

  -- Create the user using Supabase's auth.users() function
  INSERT INTO auth.users (
    instance_id,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_user_meta_data,
    created_at,
    updated_at,
    confirmation_token,
    email_change_token_current,
    email_change_token_new,
    recovery_token
  )
  VALUES (
    '00000000-0000-0000-0000-000000000000',
    'felixabayomi@icloud.com',
    crypt('Olusola1977?', gen_salt('bf')),
    now(),
    jsonb_build_object(
      'role', 'super_admin',
      'city_name', 'Admin City',
      'state', 'Admin State'
    ),
    now(),
    now(),
    encode(gen_random_bytes(32), 'hex'),
    encode(gen_random_bytes(32), 'hex'),
    encode(gen_random_bytes(32), 'hex'),
    encode(gen_random_bytes(32), 'hex')
  )
  ON CONFLICT (email) DO NOTHING
  RETURNING id INTO v_user_id;

  -- If user already exists, get their ID
  IF v_user_id IS NULL THEN
    SELECT id INTO v_user_id
    FROM auth.users
    WHERE email = 'felixabayomi@icloud.com';
  END IF;

  -- Create admin user record
  INSERT INTO admin_users (user_id, role_id)
  VALUES (v_user_id, v_role_id)
  ON CONFLICT (user_id) DO UPDATE 
  SET role_id = v_role_id;

END $$;