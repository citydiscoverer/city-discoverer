import { createClient } from '@supabase/supabase-js';

// Validate environment variables early
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing required Supabase environment variables');
}

// Create a single Supabase instance with proper configuration
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    detectSessionInUrl: true,
    autoRefreshToken: true,
    debug: true // Enable debug logging
  },
  global: {
    headers: {
      'x-application-name': 'city-discoverer'
    }
  },
  db: {
    schema: 'public'
  }
});

// Add error event listener
supabase.auth.onAuthStateChange((event, session) => {
  console.log('Supabase auth event:', event, session?.user?.email);
});