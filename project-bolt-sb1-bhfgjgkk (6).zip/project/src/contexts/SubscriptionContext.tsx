import React, { createContext, useContext, useEffect, useState } from 'react';
import { useAuth } from './AuthContext';
import { supabase } from '../lib/supabase';

interface SubscriptionTier {
  id: string;
  name: string;
  city_limit: number;
  price: number;
}

interface UserSubscription {
  id: string;
  tier_id: string;
  active: boolean;
  expires_at: string;
}

interface SubscriptionContextType {
  subscription: UserSubscription | null;
  tier: SubscriptionTier | null;
  isLoading: boolean;
  hasAccessToCity: (cityId: string) => boolean;
  canAddCity: () => boolean;
  addCity: (cityId: string) => Promise<boolean>;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export function SubscriptionProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<UserSubscription | null>(null);
  const [tier, setTier] = useState<SubscriptionTier | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [userCities, setUserCities] = useState<string[]>([]);

  useEffect(() => {
    if (!user) {
      setSubscription(null);
      setTier(null);
      setUserCities([]);
      setIsLoading(false);
      return;
    }

    const fetchSubscriptionData = async () => {
      try {
        // Fetch user's subscription
        const { data: subData, error: subError } = await supabase
          .from('user_subscriptions')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (subError) {
          console.error('Error fetching subscription:', subError);
          return;
        }

        if (subData) {
          setSubscription(subData);

          // Fetch subscription tier details
          const { data: tierData, error: tierError } = await supabase
            .from('subscription_tiers')
            .select('*')
            .eq('id', subData.tier_id)
            .maybeSingle();

          if (tierError) {
            console.error('Error fetching tier:', tierError);
            return;
          }

          setTier(tierData);
        }

        // Fetch user's cities
        const { data: citiesData, error: citiesError } = await supabase
          .from('user_cities')
          .select('city_id')
          .eq('user_id', user.id);

        if (citiesError) {
          console.error('Error fetching cities:', citiesError);
          return;
        }

        setUserCities(citiesData?.map(c => c.city_id) || []);
      } catch (error) {
        console.error('Error in subscription data fetch:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSubscriptionData();

    // Subscribe to changes
    const subscription = supabase
      .channel('subscription-changes')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'user_subscriptions',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          fetchSubscriptionData();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [user]);

  const hasAccessToCity = (cityId: string): boolean => {
    return userCities.includes(cityId);
  };

  const canAddCity = (): boolean => {
    if (!subscription || !tier || !subscription.active || new Date(subscription.expires_at) < new Date()) {
      return false;
    }
    return userCities.length < tier.city_limit;
  };

  const addCity = async (cityId: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const { data, error } = await supabase
        .from('user_cities')
        .insert({
          user_id: user.id,
          city_id: cityId
        })
        .select()
        .single();

      if (error) throw error;
      return !!data;
    } catch (error) {
      console.error('Error adding city:', error);
      return false;
    }
  };

  return (
    <SubscriptionContext.Provider value={{
      subscription,
      tier,
      isLoading,
      hasAccessToCity,
      canAddCity,
      addCity
    }}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription() {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
}