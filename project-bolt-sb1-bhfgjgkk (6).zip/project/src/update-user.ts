import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

async function updateUserCity() {
  try {
    // First, check if Cumberland, Maryland exists in city_guides
    const { data: existingCity, error: cityError } = await supabase
      .from('city_guides')
      .select('id')
      .eq('city_name', 'Cumberland')
      .eq('state', 'Maryland')
      .single();

    let cityId;

    if (!existingCity) {
      // Create the city if it doesn't exist
      const { data: newCity, error: createError } = await supabase
        .from('city_guides')
        .insert({
          city_name: 'Cumberland',
          state: 'Maryland',
          basic_info: {},
          local_attractions: [],
          restaurants: [],
          transportation: {},
          accommodations: [],
          local_tips: {},
          history_culture: {},
          audio_guides: {},
          walking_tours: [],
          seasonal_recommendations: {},
          architecture: {},
          etiquette: {}
        })
        .select()
        .single();

      if (createError) throw createError;
      cityId = newCity.id;
    } else {
      cityId = existingCity.id;
    }

    // Update user metadata
    const { error: updateError } = await supabase.auth.admin.updateUserById(
      'felixabaomi@icloud.com',
      {
        user_metadata: {
          initial_city_id: cityId,
          initial_city_name: 'Cumberland',
          initial_state: 'Maryland'
        }
      }
    );

    if (updateError) throw updateError;
    console.log('Successfully updated user city to Cumberland, Maryland');

  } catch (error) {
    console.error('Error updating user:', error);
  }
}

updateUserCity();