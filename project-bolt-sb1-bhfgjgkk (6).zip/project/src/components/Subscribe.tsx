import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { STRIPE_PRODUCTS } from '../stripe-config';
import { MapPin, Calendar, Star, Shield, Check, ArrowLeft } from 'lucide-react';

interface Plan {
  id: keyof typeof STRIPE_PRODUCTS;
  name: string;
  price: string;
  description: string;
  features: string[];
  icon: typeof MapPin;
}

const plans: Plan[] = [
  {
    id: 'MONTHLY_EXPLORER',
    name: 'Monthly Explorer Pass',
    price: '$9.99/month',
    description: 'Perfect for travelers and digital nomads',
    features: [
      'Access to your chosen city guide',
      'Real-time travel tips',
      'Local discoveries',
      'Premium city insights'
    ],
    icon: MapPin
  },
  {
    id: 'YEARLY_EXPLORER',
    name: 'Yearly Explorer Pass',
    price: '$99/year',
    description: 'Best value for urban explorers',
    features: [
      'All Monthly Pass features',
      'Save 17% annually',
      'Offline access',
      'Priority support'
    ],
    icon: Calendar
  },
  {
    id: 'GIFT_MEMBERSHIP',
    name: 'Gift Membership',
    price: '$99 one-time',
    description: 'Perfect for gifting to travel lovers',
    features: [
      '12 months of premium access',
      'Special gift presentation',
      'All premium features',
      'Transferable to recipient'
    ],
    icon: Star
  },
  {
    id: 'CUSTOM_ITINERARY',
    name: 'Custom Itinerary Pack',
    price: '$39.99 one-time',
    description: 'Tailored travel planning',
    features: [
      'Personalized 1-3 day plan',
      'Local recommendations',
      'Transit tips',
      'PDF & mobile formats'
    ],
    icon: Shield
  }
];

const Subscribe: React.FC = () => {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cityName, setCityName] = useState('');
  const [state, setState] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlan) {
      setError('Please select a subscription plan');
      return;
    }

    if (!cityName || !state) {
      setError('Please enter both city and state');
      return;
    }

    setError('');
    setIsLoading(true);

    try {
      // Check if the city already exists
      const { data: existingCity, error: checkError } = await supabase
        .from('city_guides')
        .select('id')
        .eq('city_name', cityName)
        .eq('state', state)
        .single();

      let cityId;

      if (existingCity) {
        cityId = existingCity.id;
      } else {
        // Create new city in city_guides table
        const { data: newCity, error: cityError } = await supabase
          .from('city_guides')
          .insert({
            city_name: cityName,
            state: state,
            basic_info: {},
            local_attractions: [],
            restaurants: [],
            transportation: {},
            accommodations: [],
            local_tips: {},
            history_culture: {},
            audio_guides: {},
            walking_tours: [],
            seasonal_recommendations: {},
            architecture: {},
            etiquette: {}
          })
          .select()
          .single();

        if (cityError) throw cityError;
        if (!newCity) throw new Error('Failed to create city');
        
        cityId = newCity.id;
      }

      // Create user account with city metadata
      const { data: { user }, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            role: 'subscriber',
            initial_city_id: cityId,
            initial_city_name: cityName,
            initial_state: state
          }
        }
      });

      if (signUpError) throw signUpError;
      if (!user) throw new Error('Failed to create account');

      // Create user_cities entry
      const { error: userCityError } = await supabase
        .from('user_cities')
        .insert({
          user_id: user.id,
          city_id: cityId
        });

      if (userCityError) throw userCityError;

      const product = STRIPE_PRODUCTS[selectedPlan as keyof typeof STRIPE_PRODUCTS];

      // Create checkout session
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/stripe-checkout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          price_id: product.priceId,
          success_url: `${window.location.origin}/cities/${cityId}?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${window.location.origin}/subscribe`,
          mode: product.mode,
          metadata: {
            initial_city_id: cityId
          }
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create checkout session');
      }

      const { url } = await response.json();
      
      if (url) {
        window.location.href = url;
      } else {
        throw new Error('No checkout URL received');
      }
    } catch (err: any) {
      console.error('Error during subscription:', err);
      setError(err.message || 'An error occurred during subscription');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Link
            to="/"
            className="inline-flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Home
          </Link>
        </div>

        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Choose Your City Discovery Plan
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Select the perfect plan to unlock your next city experience
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-4 lg:gap-8">
          {plans.map((plan) => {
            const Icon = plan.icon;
            return (
              <div
                key={plan.id}
                className={`relative rounded-2xl shadow-lg transition-all duration-200 ${
                  selectedPlan === plan.id
                    ? 'border-2 border-blue-500 bg-blue-50'
                    : 'border border-gray-200 bg-white hover:border-blue-300'
                }`}
              >
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    <Icon className={`w-8 h-8 ${
                      selectedPlan === plan.id ? 'text-blue-600' : 'text-gray-600'
                    }`} />
                    {selectedPlan === plan.id && (
                      <Check className="w-6 h-6 text-blue-600" />
                    )}
                  </div>
                  <h3 className="mt-4 text-xl font-semibold text-gray-900">{plan.name}</h3>
                  <p className="mt-2 text-2xl font-bold text-gray-900">{plan.price}</p>
                  <p className="mt-2 text-sm text-gray-500">{plan.description}</p>
                  <ul className="mt-6 space-y-3">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm text-gray-600">
                        <Check className="w-4 h-4 mr-2 text-green-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={() => setSelectedPlan(plan.id)}
                    className={`mt-6 w-full py-3 px-4 rounded-lg text-sm font-semibold transition-colors ${
                      selectedPlan === plan.id
                        ? 'bg-blue-600 text-white hover:bg-blue-700'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    }`}
                  >
                    {selectedPlan === plan.id ? 'Selected' : 'Select Plan'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 max-w-md mx-auto bg-white rounded-lg shadow-sm p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">
              Create Your Account
            </h2>

            {error && (
              <div className="bg-red-50 text-red-700 p-3 rounded-md text-sm">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email address
              </label>
              <input
                id="email"
                type="email"
                required
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <input
                id="password"
                type="password"
                required
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="city" className="block text-sm font-medium text-gray-700">
                  City Name
                </label>
                <input
                  id="city"
                  type="text"
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  value={cityName}
                  onChange={(e) => setCityName(e.target.value)}
                  placeholder="e.g. Portland"
                />
              </div>

              <div>
                <label htmlFor="state" className="block text-sm font-medium text-gray-700">
                  State
                </label>
                <input
                  id="state"
                  type="text"
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  placeholder="e.g. Oregon"
                />
              </div>
            </div>

            <p className="text-sm text-gray-500">
              Your subscription includes access to one city guide
            </p>

            <button
              type="submit"
              disabled={isLoading || !selectedPlan || !cityName || !state}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Creating Account...' : 'Create Account & Subscribe'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Subscribe;