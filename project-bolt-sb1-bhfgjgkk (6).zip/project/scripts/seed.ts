import { db } from '../src/lib/db';
import { auth } from '../src/lib/auth';
import { adminRoles, adminUsers, cities, categories, content } from '../src/lib/db/schema';
import { randomBytes } from 'crypto';

async function seed() {
  try {
    console.log('Starting database seed...');

    // Create admin user
    const adminUser = await auth.signUp('admin@example.com', 'admin123', {
      role: 'super_admin'
    });

    console.log('Created admin user:', adminUser.email);

    // Create super_admin role
    const roleId = randomBytes(16).toString('hex');
    await db.insert(adminRoles).values({
      id: roleId,
      name: 'super_admin',
      permissions: {
        cities: { create: true, read: true, update: true, delete: true },
        categories: { create: true, read: true, update: true, delete: true },
        content: { create: true, read: true, update: true, delete: true },
        roles: { create: true, read: true, update: true, delete: true },
        users: { create: true, read: true, update: true, delete: true }
      }
    });

    console.log('Created super_admin role');

    // Assign role to admin user
    const adminUserId = randomBytes(16).toString('hex');
    await db.insert(adminUsers).values({
      id: adminUserId,
      userId: adminUser.id,
      roleId: roleId
    });

    console.log('Assigned super_admin role to admin user');

    // Create example city
    const cityId = randomBytes(16).toString('hex');
    await db.insert(cities).values({
      id: cityId,
      name: 'Portland',
      state: 'OR'
    });

    console.log('Created example city: Portland, OR');

    // Create example category
    const categoryId = randomBytes(16).toString('hex');
    await db.insert(categories).values({
      id: categoryId,
      name: 'Local Attractions'
    });

    console.log('Created example category: Local Attractions');

    // Create example content
    const contentId = randomBytes(16).toString('hex');
    await db.insert(content).values({
      id: contentId,
      cityId: cityId,
      categoryId: categoryId,
      title: 'Portland Attractions',
      description: 'Must-visit places in Portland',
      content: {
        sections: [
          {
            title: 'Powell\'s City of Books',
            description: 'The largest independent bookstore in the world',
            location: 'Downtown Portland',
            rating: 4.8
          },
          {
            title: 'Portland Japanese Garden',
            description: 'An authentic Japanese garden experience',
            location: 'Washington Park',
            rating: 4.7
          }
        ]
      }
    });

    console.log('Created example content for Portland attractions');
    console.log('Seed completed successfully');

  } catch (error) {
    console.error('Error during seed:', error);
    process.exit(1);
  }
}

seed();