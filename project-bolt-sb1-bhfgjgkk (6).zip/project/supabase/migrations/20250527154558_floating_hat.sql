/*
  # Assign cities to legacy user
  
  1. New Tables
    - Ensures cities exist in city_guides table
    - Creates legacy user subscription tier
  
  2. Data Updates
    - Assigns subscription tier to user
    - Links cities to user's account
*/

-- First ensure both cities exist in city_guides
INSERT INTO city_guides (city_name, state, basic_info, local_attractions, restaurants, transportation, accommodations, local_tips, history_culture, audio_guides, walking_tours, seasonal_recommendations, architecture, etiquette)
VALUES 
  ('Cumberland', 'MD', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}'),
  ('Wiley Ford', 'WV', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}')
ON CONFLICT (city_name, state) DO NOTHING;

-- Create a special tier for legacy users if it doesn't exist
INSERT INTO subscription_tiers (name, city_limit, price)
VALUES ('Legacy User', 2, 0)
ON CONFLICT (name) DO NOTHING;

-- Get the user ID for the email and assign subscription
WITH user_data AS (
  SELECT id 
  FROM auth.users 
  WHERE email = 'felixabayomi@icloud.com'
),
tier_data AS (
  SELECT id 
  FROM subscription_tiers 
  WHERE name = 'Legacy User'
)
INSERT INTO user_subscriptions (user_id, tier_id, active, expires_at)
SELECT 
  user_data.id,
  tier_data.id,
  true,
  '2099-12-31 23:59:59'::timestamptz
FROM user_data, tier_data
WHERE EXISTS (SELECT 1 FROM user_data)
ON CONFLICT (user_id) 
DO UPDATE SET 
  tier_id = EXCLUDED.tier_id,
  active = EXCLUDED.active,
  expires_at = EXCLUDED.expires_at;

-- Add user cities
WITH user_data AS (
  SELECT id 
  FROM auth.users 
  WHERE email = 'felixabayomi@icloud.com'
),
city_data AS (
  SELECT id 
  FROM city_guides 
  WHERE (city_name = 'Cumberland' AND state = 'MD') 
     OR (city_name = 'Wiley Ford' AND state = 'WV')
)
INSERT INTO user_cities (user_id, city_id)
SELECT 
  user_data.id,
  city_data.id
FROM user_data
CROSS JOIN city_data
WHERE EXISTS (SELECT 1 FROM user_data)
ON CONFLICT (user_id, city_id) DO NOTHING;