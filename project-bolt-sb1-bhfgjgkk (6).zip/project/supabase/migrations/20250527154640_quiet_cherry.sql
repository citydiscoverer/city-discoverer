/*
  # Assign Cities to Legacy User
  
  1. New Data
    - Creates Cumberland, MD and Wiley Ford, WV in city_guides if they don't exist
    - Creates Legacy User subscription tier if it doesn't exist
    - Assigns both cities to the specified user
    - Sets up subscription for the user
  
  2. Changes
    - Adds user subscription with Legacy User tier
    - Links user to both cities
    
  3. Security
    - No changes to RLS policies
*/

-- First ensure both cities exist in city_guides
INSERT INTO city_guides (city_name, state, basic_info, local_attractions, restaurants, transportation, accommodations, local_tips, history_culture, audio_guides, walking_tours, seasonal_recommendations, architecture, etiquette)
VALUES 
  ('Cumberland', 'MD', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}'),
  ('Wiley Ford', 'WV', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}')
ON CONFLICT (city_name, state) DO NOTHING
RETURNING id;

-- Create a special tier for legacy users if it doesn't exist
INSERT INTO subscription_tiers (name, city_limit, price)
VALUES ('Legacy User', 2, 0)
ON CONFLICT (name) DO NOTHING
RETURNING id;

-- Get the user ID and add subscription
DO $$
DECLARE
  v_user_id uuid;
  v_tier_id uuid;
  v_cumberland_id uuid;
  v_wiley_ford_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'felixabayomi@icloud.com';

  -- Get tier ID
  SELECT id INTO v_tier_id
  FROM subscription_tiers
  WHERE name = 'Legacy User';

  -- Get city IDs
  SELECT id INTO v_cumberland_id
  FROM city_guides
  WHERE city_name = 'Cumberland' AND state = 'MD';

  SELECT id INTO v_wiley_ford_id
  FROM city_guides
  WHERE city_name = 'Wiley Ford' AND state = 'WV';

  -- Insert or update subscription
  INSERT INTO user_subscriptions (user_id, tier_id, active, expires_at)
  VALUES (v_user_id, v_tier_id, true, '2099-12-31 23:59:59'::timestamptz)
  ON CONFLICT (user_id)
  DO UPDATE SET
    tier_id = EXCLUDED.tier_id,
    active = EXCLUDED.active,
    expires_at = EXCLUDED.expires_at;

  -- Insert city assignments
  INSERT INTO user_cities (user_id, city_id)
  VALUES 
    (v_user_id, v_cumberland_id),
    (v_user_id, v_wiley_ford_id)
  ON CONFLICT DO NOTHING;
END $$;