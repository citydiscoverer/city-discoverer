/*
  # Add Cumberland, MD city guide data

  1. New Data
    - Adds Cumberland, MD to the city_guides table with comprehensive information including:
      - Basic information
      - Local attractions
      - Restaurants
      - Transportation details
      - Accommodations
      - Local tips
      - Historical and cultural information
      - Walking tours
      - Seasonal recommendations
      - Architecture highlights
      - Local etiquette
*/

INSERT INTO city_guides (
  city_name,
  state,
  basic_info,
  local_attractions,
  restaurants,
  transportation,
  accommodations,
  local_tips,
  history_culture,
  audio_guides,
  walking_tours,
  seasonal_recommendations,
  architecture,
  etiquette
) VALUES (
  'Cumberland',
  'MD',
  '{
    "population": "18,569",
    "year_estimate": 2025,
    "founded": "1787",
    "geography": "Bowl-shaped valley at the entrance to the Cumberland Narrows, along the Potomac River",
    "region": "Western Maryland",
    "language": "English",
    "currency": "USD",
    "coordinates": [39.6491, -78.7697]
  }',
  '[
    {
      "name": "Great Allegheny Passage",
      "description": "A 150-mile trail connecting Cumberland to Pittsburgh.",
      "tags": ["Biking", "Hiking", "Scenic Trail"]
    },
    {
      "name": "C&O Canal National Historical Park",
      "description": "Features the historic Paw Paw Tunnel and scenic towpaths.",
      "tags": ["History", "Nature", "Hiking"]
    },
    {
      "name": "Western Maryland Scenic Railroad",
      "description": "Scenic train rides through the Allegheny Mountains.",
      "tags": ["Scenic", "Train", "Tourism"]
    },
    {
      "name": "Canal Place Heritage Area",
      "description": "Historical and cultural hub at the confluence of canal and railway.",
      "tags": ["History", "Culture", "Recreation"]
    },
    {
      "name": "Allegany Museum",
      "description": "Museum showcasing regional history and culture.",
      "tags": ["Museum", "Local History"]
    }
  ]',
  '[
    {
      "name": "Ristorante Ottaviani",
      "cuisine": "Italian",
      "price_range": "$$",
      "specialties": ["Homemade pasta", "Seafood dishes"]
    },
    {
      "name": "Baltimore Street Grill",
      "cuisine": "American",
      "price_range": "$$",
      "specialties": ["Burgers", "Sandwiches", "Local beers"]
    },
    {
      "name": "Puccini Restaurant",
      "cuisine": "Italian",
      "price_range": "$$",
      "specialties": ["Wood-fired pizzas", "Pasta dishes"]
    },
    {
      "name": "The Crabby Pig",
      "cuisine": "Seafood, Barbecue",
      "price_range": "$$",
      "specialties": ["Crab cakes", "Ribs"]
    }
  ]',
  '{
    "public_transit": "Allegany County Transit (ACT)",
    "intercity": "Amtrak''s Capitol Limited",
    "highways": ["Interstate 68"]
  }',
  '[
    {
      "name": "Ramada by Wyndham Cumberland Downtown",
      "type": "Hotel",
      "features": ["Downtown location", "Complimentary breakfast", "Fitness center"]
    },
    {
      "name": "Cumberland Inn & Spa",
      "type": "Boutique Hotel",
      "features": ["Historic building", "Spa services", "Personalized amenities"]
    },
    {
      "name": "Fairfield Inn & Suites by Marriott Cumberland",
      "type": "Hotel",
      "features": ["Modern rooms", "Indoor pool", "Fitness center"]
    }
  ]',
  '{
    "walking_tour": "Explore 32 historic sites with the self-guided tour map.",
    "artisan_market": "Canal Place hosts artisan markets and music on weekends.",
    "nature_escape": "Rocky Gap State Park offers hiking, a lake, and a casino."
  }',
  '{
    "fort_cumberland": "Established in 1754, pivotal in the French and Indian War.",
    "washington_hq": "Log cabin museum where George Washington stayed.",
    "historical_society": "Preserves and exhibits regional history and artifacts."
  }',
  '{
    "walking_tour_pdf": "Cumberland Historic Walking Tour (PDF)",
    "canal_center": "Interactive exhibits at Canal Place Visitor Center"
  }',
  '[
    {
      "name": "Downtown Cumberland Walking Tour",
      "route": "Starts at Allegany Museum, along Baltimore Street",
      "points_of_interest": ["Allegany Museum", "George Washington''s HQ", "Historic churches"],
      "duration_hours": 1.5
    }
  ]',
  '{
    "spring": "Great for biking/hiking trails.",
    "summer": "Festivals and concerts at Canal Place.",
    "fall": "Foliage in surrounding mountains.",
    "winter": "Holiday events and museum visits."
  }',
  '{
    "notables": [
      {
        "name": "Allegany County Courthouse",
        "style": "Romanesque Revival",
        "year": 1893
      },
      {
        "name": "Downtown Historic District",
        "style": "19th-century commercial architecture"
      },
      {
        "name": "Washington Street Historic District",
        "style": "Victorian-era homes and churches"
      }
    ]
  }',
  '{
    "community_engagement": "Locals value friendliness and civic involvement.",
    "support_local": "Visitors are encouraged to shop local and attend events."
  }'
);