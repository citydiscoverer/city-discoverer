/*
  # Add Nashville city guide data
  
  1. New Data
    - Adds Nashville, TN to the city_guides table
    - Includes comprehensive city information including:
      - Basic information
      - Local attractions
      - Restaurants
      - Transportation
      - Accommodations
      - Local tips
      - History and culture
      - Audio guides
      - Walking tours
      - Seasonal recommendations
      - Architecture
      - Etiquette
*/

INSERT INTO city_guides (
  city_name,
  state,
  basic_info,
  local_attractions,
  restaurants,
  transportation,
  accommodations,
  local_tips,
  history_culture,
  audio_guides,
  walking_tours,
  seasonal_recommendations,
  architecture,
  etiquette
) VALUES (
  'Nashville',
  'TN',
  '{
    "population": "687,150",
    "year_estimate": 2025,
    "founded": "1779",
    "geography": "Situated in the Central Basin, surrounded by the Highland Rim, with rolling hills and the Cumberland River",
    "region": "Middle Tennessee, Southeastern United States",
    "language": "English",
    "currency": "USD",
    "coordinates": [36.174465, -86.76796]
  }',
  '[
    {
      "name": "Grand Ole Opry",
      "description": "World-famous country music venue hosting live performances.",
      "tags": ["Music", "Live Performances", "Cultural Icon"]
    },
    {
      "name": "Ryman Auditorium",
      "description": "Historic venue known as the ''Mother Church of Country Music.''",
      "tags": ["Historic", "Music", "Architecture"]
    },
    {
      "name": "Country Music Hall of Fame and Museum",
      "description": "Comprehensive exhibits on the history and influence of country music.",
      "tags": ["Music", "Museum", "Country"]
    },
    {
      "name": "The Parthenon",
      "description": "Full-scale replica of the Athenian Parthenon featuring a museum.",
      "tags": ["Architecture", "Art", "Museum"]
    },
    {
      "name": "Broadway",
      "description": "Lively street filled with honky-tonks, bars, and live music venues.",
      "tags": ["Entertainment", "Nightlife", "Music"]
    }
  ]',
  '[
    {
      "name": "The Catbird Seat",
      "cuisine": "Contemporary American",
      "price_range": "$$$$",
      "specialties": ["Tasting menus", "Seasonal ingredients"]
    },
    {
      "name": "Prince''s Hot Chicken Shack",
      "cuisine": "Southern",
      "price_range": "$",
      "specialties": ["Hot chicken"]
    },
    {
      "name": "Husk",
      "cuisine": "Southern",
      "price_range": "$$$",
      "specialties": ["Locally sourced Southern cuisine"]
    },
    {
      "name": "Mas Tacos Por Favor",
      "cuisine": "Mexican",
      "price_range": "$",
      "specialties": ["Tacos", "Elote"]
    },
    {
      "name": "Etch",
      "cuisine": "Global Fusion",
      "price_range": "$$$",
      "specialties": ["Innovative international dishes"]
    }
  ]',
  '{
    "public_transit": "WeGo Public Transit",
    "airport": "Nashville International Airport (BNA)",
    "rideshare": ["Uber", "Lyft"],
    "commuter_rail": "Music City Star (East suburbs)"
  }',
  '[
    {
      "name": "The Hermitage Hotel",
      "type": "Luxury Hotel",
      "features": ["Historic architecture", "Fine dining"]
    },
    {
      "name": "21c Museum Hotel",
      "type": "Boutique Hotel",
      "features": ["Contemporary art", "Museum integration"]
    },
    {
      "name": "Gaylord Opryland Resort",
      "type": "Resort Hotel",
      "features": ["Indoor gardens", "Convention center"]
    },
    {
      "name": "Noelle",
      "type": "Boutique Hotel",
      "features": ["Art deco design", "Rooftop bar"]
    },
    {
      "name": "The Joseph",
      "type": "Luxury Hotel",
      "features": ["Italian-inspired", "Rooftop pool"]
    }
  ]',
  '{
    "printers_alley": "Hidden bars and music venues tucked in a historic alleyway.",
    "five_points": "Indie shops and local eateries in East Nashville.",
    "radnor_lake": "Tranquil park for hiking and wildlife viewing.",
    "bluebird_cafe": "Intimate setting for hearing Nashville songwriters.",
    "twelve_south": "Trendy area with murals, boutiques, and cafes."
  }',
  '{
    "historical_background": "Founded in 1779; became Tennessee''s capital in 1843.",
    "cultural_significance": "Nicknamed ''Music City'' for its deep musical roots.",
    "notable_events": "Home of the Fisk Jubilee Singers and country music revolution."
  }',
  '{
    "voicemap": "Self-guided audio tours around major Nashville landmarks.",
    "walkin_nashville": "Music history-focused guided tours.",
    "parthenon_audio": "Narrated exploration of Nashville''s replica Parthenon."
  }',
  '[
    {
      "name": "Downtown Music City Tour",
      "route": "Explore the heart of Nashville''s music scene.",
      "points_of_interest": ["Ryman Auditorium", "Broadway", "Country Music Hall of Fame"],
      "duration_hours": 2
    },
    {
      "name": "Germantown Food Tour",
      "route": "Tasting tour in one of Nashville''s oldest neighborhoods.",
      "points_of_interest": ["Local restaurants", "Historic homes"],
      "duration_hours": 1.5
    },
    {
      "name": "Civil Rights Tour",
      "route": "Landmarks central to Nashville''s civil rights movement.",
      "points_of_interest": ["Fisk University", "Woolworth''s", "Public Square"],
      "duration_hours": 2
    }
  ]',
  '{
    "spring": "Cherry Blossom Festival and outdoor concerts flourish.",
    "summer": "July 4th fireworks and bustling rooftop bar season.",
    "fall": "Foliage and outdoor music events like Live on the Green.",
    "winter": "Cheekwood LIGHTS and cozy indoor music venues."
  }',
  '{
    "notables": [
      {
        "name": "Ryman Auditorium",
        "style": "Gothic Revival",
        "note": "One of the most iconic music halls in the U.S."
      },
      {
        "name": "AT&T Building",
        "style": "Modern",
        "note": "Skyscraper nicknamed the ''Batman Building''"
      },
      {
        "name": "Tennessee State Capitol",
        "style": "Greek Revival",
        "note": "One of the oldest working capitols in the country"
      },
      {
        "name": "Union Station Hotel",
        "style": "Romanesque",
        "note": "Converted from a 1900s train station"
      },
      {
        "name": "Scarritt Bennett Center",
        "style": "Collegiate Gothic",
        "note": "Known for weddings and events"
      }
    ]
  }',
  '{
    "music_etiquette": "Clap and cheer even in casual music settings.",
    "hospitality": "Southern friendliness is appreciated.",
    "tipping": "15–20% is standard at restaurants and bars.",
    "dress_code": "Casual attire is fine, but dress up slightly for nicer venues."
  }'
);