import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface AssignSubscriptionBody {
  userId: string;
  tierId: string;
}

interface AssignCitiesBody {
  userId: string;
  cityIds: string[];
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const authHeader = req.headers.get('Authorization');

    if (!authHeader) {
      throw new Error('No authorization header');
    }

    // Verify admin status
    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    // Verify admin role
    const { data: adminData, error: adminError } = await supabase
      .from('admin_users')
      .select('role_id')
      .eq('user_id', user.id)
      .single();

    if (adminError || !adminData) {
      throw new Error('Not an admin');
    }

    // Handle different endpoints
    switch (url.pathname) {
      case '/functions/v1/manage-subscription/assign-subscription': {
        const { userId, tierId }: AssignSubscriptionBody = await req.json();

        // Check if user already has a subscription
        const { data: existingSub } = await supabase
          .from('user_subscriptions')
          .select()
          .eq('user_id', userId)
          .single();

        if (existingSub) {
          // Update existing subscription
          const { error: updateError } = await supabase
            .from('user_subscriptions')
            .update({ subscription_tier_id: tierId })
            .eq('user_id', userId);

          if (updateError) throw updateError;
        } else {
          // Create new subscription
          const { error: insertError } = await supabase
            .from('user_subscriptions')
            .insert({ user_id: userId, subscription_tier_id: tierId });

          if (insertError) throw insertError;
        }

        return new Response(
          JSON.stringify({ success: true }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      case '/functions/v1/manage-subscription/assign-cities': {
        const { userId, cityIds }: AssignCitiesBody = await req.json();

        // Get user's subscription tier
        const { data: subscription, error: subError } = await supabase
          .from('user_subscriptions')
          .select('subscription_tier_id')
          .eq('user_id', userId)
          .single();

        if (subError || !subscription) {
          throw new Error('User has no subscription');
        }

        // Get tier details
        const { data: tier, error: tierError } = await supabase
          .from('subscription_tiers')
          .select('max_cities')
          .eq('id', subscription.subscription_tier_id)
          .single();

        if (tierError || !tier) {
          throw new Error('Invalid subscription tier');
        }

        // Validate city count
        if (cityIds.length > tier.max_cities) {
          throw new Error(`Cannot assign more than ${tier.max_cities} cities`);
        }

        // Remove existing cities
        await supabase
          .from('user_cities')
          .delete()
          .eq('user_id', userId);

        // Add new cities
        if (cityIds.length > 0) {
          const { error: insertError } = await supabase
            .from('user_cities')
            .insert(
              cityIds.map(cityId => ({
                user_id: userId,
                city_id: cityId
              }))
            );

          if (insertError) throw insertError;
        }

        return new Response(
          JSON.stringify({ success: true }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      default:
        throw new Error('Invalid endpoint');
    }
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});