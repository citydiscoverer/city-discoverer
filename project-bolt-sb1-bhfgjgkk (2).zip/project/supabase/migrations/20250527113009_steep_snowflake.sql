/*
  # Update Wiley Ford Basic Information content

  Updates the content for Wiley Ford's Basic Information category with detailed city data.
*/

DO $$ 
DECLARE
  wiley_ford_id uuid;
  basic_info_id uuid;
BEGIN
  -- Get Wiley Ford city ID
  SELECT id INTO wiley_ford_id FROM cities WHERE name = 'Wiley Ford, WV';
  
  -- Get Basic Information category ID
  SELECT id INTO basic_info_id FROM categories WHERE name = 'Basic Information';

  -- Update content for Wiley Ford Basic Information
  UPDATE content 
  SET 
    title = 'Wiley Ford, WV - Basic Information',
    description = 'Essential details and quick facts about Wiley Ford, West Virginia',
    content = jsonb_build_object(
      'emoji', 'ℹ️',
      'tagline', 'Everything you need to know about Wiley Ford at a glance',
      'sections', jsonb_build_array(
        jsonb_build_object(
          'title', 'Quick Facts',
          'icon', 'Info',
          'details', jsonb_build_object(
            'Population', 'Approximately 588 residents as of 2023',
            'Founded', 'Early 20th century; named after Mr. Wiley, who settled near a ford in the area',
            'Geography', 'Located along the North Branch of the Potomac River, adjacent to Cumberland, MD',
            'Region', 'Appalachian Mountains, Eastern Panhandle of West Virginia',
            'Language', 'English',
            'Currency', 'USD',
            'Coordinates', '39.6265° N, 78.7756° W'
          )
        ),
        jsonb_build_object(
          'title', 'Location & Setting',
          'icon', 'MapPin',
          'content', ARRAY[
            'Situated in the scenic Appalachian Mountains region',
            'Part of the Eastern Panhandle of West Virginia',
            'Adjacent to Cumberland, Maryland',
            'Located along the North Branch of the Potomac River'
          ]
        ),
        jsonb_build_object(
          'title', 'Community Overview',
          'icon', 'Users',
          'content', ARRAY[
            'Small, close-knit community with around 588 residents',
            'Known for its friendly, welcoming atmosphere',
            'Strong ties to neighboring Cumberland, MD',
            'Home to the Greater Cumberland Regional Airport'
          ]
        )
      )
    )
  WHERE city_id = wiley_ford_id AND category_id = basic_info_id;
END $$;