/*
  # Fix admin roles policy recursion

  1. Changes
    - Drop the existing recursive policy on admin_roles table
    - Create a new non-recursive policy that checks admin status directly
    
  2. Security
    - Maintains security by ensuring only super admins can manage roles
    - Uses a direct check against the admin_users and admin_roles tables
    - Prevents infinite recursion by avoiding nested EXISTS clauses
*/

-- Drop the existing policy that causes recursion
DROP POLICY IF EXISTS "Super admins can manage roles" ON admin_roles;

-- Create new policy without recursion
CREATE POLICY "Super admins can manage roles"
ON admin_roles
FOR ALL
TO public
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid() 
    AND ar.name = 'super_admin'
    AND au.role_id = ar.id
  )
);