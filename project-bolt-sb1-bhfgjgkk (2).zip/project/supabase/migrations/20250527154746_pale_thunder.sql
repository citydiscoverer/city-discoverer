/*
  # Assign Cities to Legacy User

  1. New Data
    - Creates Cumberland, MD and Wiley Ford, WV in city_guides if they don't exist
    - Creates Legacy User subscription tier if it doesn't exist
    - Assigns both cities to felixabayomi@icloud.com
    - Sets up legacy subscription for the user

  2. Security
    - No changes to RLS policies
    - Uses existing table security

  3. Changes
    - Adds two cities to city_guides if not present
    - Creates legacy subscription tier
    - Creates user subscription
    - Assigns cities to user
*/

-- First ensure both cities exist in city_guides
INSERT INTO city_guides (city_name, state, basic_info, local_attractions, restaurants, transportation, accommodations, local_tips, history_culture, audio_guides, walking_tours, seasonal_recommendations, architecture, etiquette)
VALUES 
  ('Cumberland', 'MD', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}'),
  ('Wiley Ford', 'WV', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}')
ON CONFLICT ON CONSTRAINT unique_city_state DO NOTHING;

-- Create a special tier for legacy users if it doesn't exist
INSERT INTO subscription_tiers (name, city_limit, price)
VALUES ('Legacy User', 2, 0)
ON CONFLICT ON CONSTRAINT subscription_tiers_name_key DO NOTHING;

-- Get the user ID and add subscription
DO $$
DECLARE
  v_user_id uuid;
  v_tier_id uuid;
  v_cumberland_id uuid;
  v_wiley_ford_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'felixabayomi@icloud.com';

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User not found with email felixabayomi@icloud.com';
  END IF;

  -- Get tier ID
  SELECT id INTO v_tier_id
  FROM subscription_tiers
  WHERE name = 'Legacy User';

  IF v_tier_id IS NULL THEN
    RAISE EXCEPTION 'Legacy User tier not found';
  END IF;

  -- Get city IDs
  SELECT id INTO v_cumberland_id
  FROM city_guides
  WHERE city_name = 'Cumberland' AND state = 'MD';

  SELECT id INTO v_wiley_ford_id
  FROM city_guides
  WHERE city_name = 'Wiley Ford' AND state = 'WV';

  IF v_cumberland_id IS NULL OR v_wiley_ford_id IS NULL THEN
    RAISE EXCEPTION 'One or both cities not found';
  END IF;

  -- Insert or update subscription
  INSERT INTO user_subscriptions (user_id, tier_id, active, expires_at)
  VALUES (v_user_id, v_tier_id, true, '2099-12-31 23:59:59'::timestamptz)
  ON CONFLICT ON CONSTRAINT user_subscriptions_user_id_key
  DO UPDATE SET
    tier_id = EXCLUDED.tier_id,
    active = EXCLUDED.active,
    expires_at = EXCLUDED.expires_at;

  -- Insert city assignments if they don't exist
  INSERT INTO user_cities (user_id, city_id)
  VALUES 
    (v_user_id, v_cumberland_id)
  ON CONFLICT ON CONSTRAINT user_cities_user_id_city_id_key DO NOTHING;

  INSERT INTO user_cities (user_id, city_id)
  VALUES 
    (v_user_id, v_wiley_ford_id)
  ON CONFLICT ON CONSTRAINT user_cities_user_id_city_id_key DO NOTHING;

END $$;