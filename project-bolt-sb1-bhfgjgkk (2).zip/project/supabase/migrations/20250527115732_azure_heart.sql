/*
  # Add Baltimore city data
  
  1. New Data
    - Adds Baltimore, MD to the city_guides table with comprehensive information including:
      - Basic information
      - Local attractions
      - Restaurants
      - Transportation
      - Accommodations
      - And more city-specific data
*/

INSERT INTO city_guides (
  city_name,
  state,
  basic_info,
  local_attractions,
  restaurants,
  transportation,
  accommodations,
  local_tips,
  history_culture,
  audio_guides,
  walking_tours,
  seasonal_recommendations,
  architecture,
  etiquette
) VALUES (
  'Baltimore',
  'MD',
  '{
    "population": "553,293",
    "year_estimate": 2025,
    "founded": "August 8, 1729",
    "geography": "Located in north-central Maryland along the Patapsco River near the Chesapeake Bay",
    "region": "Central Maryland",
    "language": "English",
    "currency": "USD",
    "coordinates": [39.2904, -76.6122]
  }',
  '[
    {
      "name": "National Aquarium",
      "description": "One of the nation''s top aquariums with immersive marine exhibits.",
      "tags": ["Aquarium", "Marine Life", "Family-Friendly"]
    },
    {
      "name": "Inner Harbor",
      "description": "Waterfront area with restaurants, shops, museums, and historic ships.",
      "tags": ["Waterfront", "Shopping", "Dining", "Museums"]
    },
    {
      "name": "Oriole Park at Camden Yards",
      "description": "Retro-style stadium and home of the Baltimore Orioles.",
      "tags": ["Baseball", "Stadium", "Sports"]
    },
    {
      "name": "Fort McHenry National Monument",
      "description": "Historic site of the War of 1812 and inspiration for the national anthem.",
      "tags": ["History", "National Monument", "War of 1812"]
    },
    {
      "name": "The Walters Art Museum",
      "description": "Extensive collection of art from ancient to modern.",
      "tags": ["Art", "Museum", "Culture"]
    },
    {
      "name": "American Visionary Art Museum",
      "description": "Dedicated to self-taught artists with eclectic, creative exhibits.",
      "tags": ["Art", "Visionary", "Creative"]
    }
  ]',
  '[
    {
      "name": "Thames Street Oyster House",
      "cuisine": "Seafood",
      "price_range": "$$$",
      "specialties": ["Oysters", "Lobster rolls"]
    },
    {
      "name": "La Tavola",
      "cuisine": "Italian",
      "price_range": "$$",
      "specialties": ["Homemade pasta", "Seafood dishes"]
    },
    {
      "name": "The Capital Grille",
      "cuisine": "Steakhouse",
      "price_range": "$$$",
      "specialties": ["Dry-aged steaks", "Fresh seafood"]
    },
    {
      "name": "Phillips Seafood",
      "cuisine": "Seafood",
      "price_range": "$$",
      "specialties": ["Crab cakes", "Steamed crabs"]
    }
  ]',
  '{
    "transit_agency": "Maryland Transit Administration (MTA)",
    "services": ["Bus", "Light Rail", "Subway"],
    "free_shuttle": "Charm City Circulator",
    "water_transport": "Water Taxi",
    "micromobility": "Dockless scooters and bikes"
  }',
  '[
    {
      "name": "The Ivy Hotel",
      "type": "Luxury Boutique Hotel",
      "features": ["Historic mansion", "Fine dining", "Personalized service"]
    },
    {
      "name": "Lord Baltimore Hotel",
      "type": "Historic Hotel",
      "features": ["Rooftop bar", "Classic architecture", "Central location"]
    },
    {
      "name": "Hampton Inn & Suites Baltimore Inner Harbor",
      "type": "Hotel",
      "features": ["Indoor pool", "Complimentary breakfast", "Proximity to attractions"]
    }
  ]',
  '{
    "lexington_market": "Historic market with diverse food vendors.",
    "fells_point": "Charming waterfront neighborhood with nightlife.",
    "hampden": "Quirky neighborhood known for shops and HonFest."
  }',
  '{
    "founding": "Named after Cecil Calvert, established in 1729.",
    "war_of_1812": "Site of Fort McHenry''s defense and national anthem inspiration.",
    "bo_railroad": "Home to the first commercial U.S. railroad, founded in 1827."
  }',
  '{
    "bmi": "Audio guides in English and Spanish at the Baltimore Museum of Industry.",
    "bma": "Digital exhibition guides with audio and video at the Baltimore Museum of Art.",
    "smartguide": "Mobile app with self-guided audio tours around the city."
  }',
  '[
    {
      "name": "Baltimore Heritage Tours",
      "route": "Historic neighborhoods and notable buildings.",
      "points_of_interest": ["Mount Vernon", "Federal Hill", "Inner Harbor"],
      "duration_hours": 1.5
    },
    {
      "name": "Underground Railroad Walking Tour",
      "route": "3-mile path through key historical freedom sites.",
      "points_of_interest": ["Freedom House", "Historic Churches"],
      "duration_hours": 2.5
    },
    {
      "name": "GuruWalk Tours",
      "route": "Various themes led by local guides.",
      "points_of_interest": ["Neighborhood highlights", "Hidden gems"],
      "duration_hours": 1.5
    }
  ]',
  '{
    "spring": "Festivals and blooming gardens citywide.",
    "summer": "Waterfront events and Orioles games.",
    "fall": "Artscape festival and vibrant fall foliage.",
    "winter": "Holiday lights, indoor exhibits, and markets."
  }',
  '{
    "notables": [
      {
        "name": "Baltimore Basilica",
        "style": "Neoclassical",
        "note": "First Roman Catholic cathedral in the U.S."
      },
      {
        "name": "The Belvedere Hotel",
        "style": "Beaux-Arts",
        "note": "Historic luxury hotel with rich history."
      },
      {
        "name": "Mount Vernon Place",
        "style": "19th-century",
        "note": "Home to Washington Monument and cultural landmarks."
      }
    ]
  }',
  '{
    "community_engagement": "Locals value civic pride and friendliness.",
    "support_local": "Visitors are encouraged to shop local and engage in events."
  }'
);