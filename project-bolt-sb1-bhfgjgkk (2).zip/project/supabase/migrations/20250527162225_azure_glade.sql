/*
  # Add Legacy User Cities

  1. Changes
    - Adds Cumberland, MD and Wiley Ford, WV to city_guides
    - Creates Legacy User subscription tier
    - Assigns cities to felixabayomi@icloud.com
    - Sets initial city in user metadata
*/

-- First ensure both cities exist in city_guides
INSERT INTO city_guides (city_name, state, basic_info, local_attractions, restaurants, transportation, accommodations, local_tips, history_culture, audio_guides, walking_tours, seasonal_recommendations, architecture, etiquette)
SELECT 'Cumberland', 'MD', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}'
WHERE NOT EXISTS (
  SELECT 1 FROM city_guides 
  WHERE city_name = 'Cumberland' AND state = 'MD'
);

INSERT INTO city_guides (city_name, state, basic_info, local_attractions, restaurants, transportation, accommodations, local_tips, history_culture, audio_guides, walking_tours, seasonal_recommendations, architecture, etiquette)
SELECT 'Wiley Ford', 'WV', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}'
WHERE NOT EXISTS (
  SELECT 1 FROM city_guides 
  WHERE city_name = 'Wiley Ford' AND state = 'WV'
);

-- Create a special tier for legacy users if it doesn't exist
INSERT INTO subscription_tiers (name, city_limit, price)
SELECT 'Legacy User', 2, 0
WHERE NOT EXISTS (
  SELECT 1 FROM subscription_tiers WHERE name = 'Legacy User'
);

-- Get the user ID and add subscription
DO $$
DECLARE
  v_user_id uuid;
  v_tier_id uuid;
  v_cumberland_id uuid;
  v_wiley_ford_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'felixabayomi@icloud.com';

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User not found with email felixabayomi@icloud.com';
  END IF;

  -- Get tier ID
  SELECT id INTO v_tier_id
  FROM subscription_tiers
  WHERE name = 'Legacy User';

  IF v_tier_id IS NULL THEN
    RAISE EXCEPTION 'Legacy User tier not found';
  END IF;

  -- Get city IDs
  SELECT id INTO v_cumberland_id
  FROM city_guides
  WHERE city_name = 'Cumberland' AND state = 'MD';

  SELECT id INTO v_wiley_ford_id
  FROM city_guides
  WHERE city_name = 'Wiley Ford' AND state = 'WV';

  IF v_cumberland_id IS NULL OR v_wiley_ford_id IS NULL THEN
    RAISE EXCEPTION 'One or both cities not found';
  END IF;

  -- Insert or update subscription
  INSERT INTO user_subscriptions (user_id, tier_id, active, expires_at)
  VALUES (v_user_id, v_tier_id, true, '2099-12-31 23:59:59'::timestamptz)
  ON CONFLICT (user_id) DO UPDATE 
  SET 
    tier_id = EXCLUDED.tier_id,
    active = EXCLUDED.active,
    expires_at = EXCLUDED.expires_at;

  -- Insert Cumberland city assignment
  INSERT INTO user_cities (user_id, city_id)
  SELECT v_user_id, v_cumberland_id
  WHERE NOT EXISTS (
    SELECT 1 FROM user_cities 
    WHERE user_id = v_user_id AND city_id = v_cumberland_id
  );

  -- Insert Wiley Ford city assignment
  INSERT INTO user_cities (user_id, city_id)
  SELECT v_user_id, v_wiley_ford_id
  WHERE NOT EXISTS (
    SELECT 1 FROM user_cities 
    WHERE user_id = v_user_id AND city_id = v_wiley_ford_id
  );

  -- Update user metadata with initial city
  UPDATE auth.users
  SET raw_user_meta_data = jsonb_set(
    COALESCE(raw_user_meta_data, '{}'::jsonb),
    '{initial_city_id}',
    to_jsonb(v_cumberland_id::text)
  )
  WHERE id = v_user_id;

END $$;