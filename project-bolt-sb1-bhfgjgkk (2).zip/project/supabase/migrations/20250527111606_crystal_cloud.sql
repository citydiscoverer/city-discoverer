/*
  # Add Sample Cities

  1. Changes
    - Insert sample cities into the cities table:
      - Wiley Ford, WV
      - Cumberland, MD
      - Baltimore, MD
      - Little Rock, AR
      - Nashville, TN
      - Lexington, KY

  Note: Using ON CONFLICT to handle cases where cities might already exist
*/

INSERT INTO cities (name)
VALUES 
  ('Wiley Ford, WV'),
  ('Cumberland, MD'),
  ('Baltimore, MD'),
  ('Little Rock, AR'),
  ('Nashville, TN'),
  ('Lexington, KY')
ON CONFLICT (name) DO NOTHING;