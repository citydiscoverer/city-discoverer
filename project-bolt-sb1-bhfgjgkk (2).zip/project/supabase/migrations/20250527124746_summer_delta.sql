/*
  # Add subscription management
  
  1. New Tables
    - `subscription_tiers`: Defines available subscription plans
      - `id` (uuid, primary key)
      - `name` (text): Plan name
      - `city_limit` (integer): Maximum number of cities
      - `price` (integer): Price in cents
    
    - `user_subscriptions`: Tracks user subscriptions
      - `id` (uuid, primary key)
      - `user_id` (uuid): References auth.users
      - `tier_id` (uuid): References subscription_tiers
      - `active` (boolean): Subscription status
      - `expires_at` (timestamptz): Subscription expiration
      - `cities` (uuid[]): Array of accessible city IDs
  
  2. Security
    - Enable RLS on both tables
    - Add policies for subscription management
    - Add policies to limit city access
*/

-- Create subscription_tiers table
CREATE TABLE subscription_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  city_limit integer NOT NULL,
  price integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create user_subscriptions table
CREATE TABLE user_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users ON DELETE CASCADE,
  tier_id uuid REFERENCES subscription_tiers ON DELETE RESTRICT,
  active boolean DEFAULT true,
  expires_at timestamptz NOT NULL,
  cities uuid[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE subscription_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;

-- Insert default subscription tiers
INSERT INTO subscription_tiers (name, city_limit, price) VALUES
  ('Basic', 1, 999),    -- $9.99/month, 1 city
  ('Pro', 5, 1999),     -- $19.99/month, 5 cities
  ('Business', 20, 4999); -- $49.99/month, 20 cities

-- Policies for subscription_tiers
CREATE POLICY "Allow public read access to subscription tiers"
  ON subscription_tiers
  FOR SELECT
  TO public
  USING (true);

-- Policies for user_subscriptions
CREATE POLICY "Users can view their own subscription"
  ON user_subscriptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Super admins can manage all subscriptions"
  ON user_subscriptions
  TO authenticated
  USING (is_super_admin());

-- Update cities table policies to check subscription
DROP POLICY IF EXISTS "Allow public read access to cities" ON cities;
DROP POLICY IF EXISTS "Allow authenticated users to manage cities" ON cities;

CREATE POLICY "Users can access cities in their subscription"
  ON cities
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_subscriptions
      WHERE user_id = auth.uid()
      AND active = true
      AND expires_at > now()
      AND id = ANY(cities)
    )
  );

-- Function to check if user has access to a city
CREATE OR REPLACE FUNCTION has_city_access(city_uuid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_subscriptions
    WHERE user_id = auth.uid()
    AND active = true
    AND expires_at > now()
    AND city_uuid = ANY(cities)
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to add city to user's subscription
CREATE OR REPLACE FUNCTION add_city_to_subscription(city_uuid uuid)
RETURNS boolean AS $$
DECLARE
  subscription user_subscriptions;
  tier subscription_tiers;
BEGIN
  -- Get user's subscription
  SELECT * INTO subscription
  FROM user_subscriptions
  WHERE user_id = auth.uid()
  AND active = true
  AND expires_at > now();

  -- Check if subscription exists
  IF NOT FOUND THEN
    RETURN false;
  END IF;

  -- Get subscription tier
  SELECT * INTO tier
  FROM subscription_tiers
  WHERE id = subscription.tier_id;

  -- Check city limit
  IF array_length(subscription.cities, 1) >= tier.city_limit THEN
    RETURN false;
  END IF;

  -- Add city to subscription
  UPDATE user_subscriptions
  SET cities = array_append(cities, city_uuid)
  WHERE id = subscription.id;

  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;