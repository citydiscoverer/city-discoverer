/*
  # Create Super Admin User
  
  1. Creates super_admin role if it doesn't exist
  2. Creates admin user for support@citydiscoverer.ai
  3. Sets up proper permissions
*/

-- First ensure the super_admin role exists
INSERT INTO admin_roles (name, permissions)
VALUES (
  'super_admin',
  jsonb_build_object(
    'cities', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'categories', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'content', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'roles', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true),
    'users', jsonb_build_object('create', true, 'read', true, 'update', true, 'delete', true)
  )
)
ON CONFLICT (name) 
DO UPDATE SET permissions = EXCLUDED.permissions
RETURNING id;

-- Create the auth user if it doesn't exist
DO $$
DECLARE
  v_user_id uuid;
  v_role_id uuid;
BEGIN
  -- Get or create auth user
  INSERT INTO auth.users (
    email,
    raw_user_meta_data,
    encrypted_password
  )
  VALUES (
    'support@citydiscoverer.ai',
    '{"role": "super_admin"}'::jsonb,
    -- Using Supabase's built-in encryption for 'Olusola1977?'
    crypt('Olusola1977?', gen_salt('bf'))
  )
  ON CONFLICT (email) DO UPDATE 
  SET raw_user_meta_data = '{"role": "super_admin"}'::jsonb
  RETURNING id INTO v_user_id;

  -- Get super_admin role id
  SELECT id INTO v_role_id
  FROM admin_roles
  WHERE name = 'super_admin';

  -- Create admin user record
  INSERT INTO admin_users (user_id, role_id)
  VALUES (v_user_id, v_role_id)
  ON CONFLICT (user_id) DO UPDATE 
  SET role_id = v_role_id;

END $$;