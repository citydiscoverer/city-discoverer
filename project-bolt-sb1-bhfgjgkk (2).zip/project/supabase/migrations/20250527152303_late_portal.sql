/*
  # Fix admin role policies

  1. Changes
    - Drop existing problematic policies that cause recursion
    - Create new simplified policies for admin_users and admin_roles
    - Ensure super_admin role has proper access without circular dependencies
  
  2. Security
    - Maintain RLS protection
    - Ensure super_admin role retains management capabilities
    - Prevent unauthorized access to admin functions
*/

-- Drop existing policies that cause recursion
DROP POLICY IF EXISTS "Super admins can manage users" ON admin_users;
DROP POLICY IF EXISTS "Super admins can manage roles" ON admin_roles;

-- Create new policy for admin_roles without recursion
CREATE POLICY "Super admins can manage roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    WHERE au.user_id = auth.uid() 
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);

-- Create new policy for admin_users without recursion
CREATE POLICY "Super admins can manage users"
ON admin_users
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    WHERE au.user_id = auth.uid() 
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);