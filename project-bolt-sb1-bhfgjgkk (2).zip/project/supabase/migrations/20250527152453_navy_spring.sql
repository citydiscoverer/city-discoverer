/*
  # Fix admin policies recursion

  1. Changes
    - Drop existing policies that cause recursion
    - Create simplified policies for admin_users and admin_roles
    - Add separate read and write policies
    - Remove circular dependencies between tables

  2. Security
    - Maintain proper access control for super admins
    - Allow admins to read their own data
    - Prevent unauthorized access
*/

-- First, drop all existing policies to start fresh
DROP POLICY IF EXISTS "Super admins can manage users" ON admin_users;
DROP POLICY IF EXISTS "Super admins can manage roles" ON admin_roles;
DROP POLICY IF EXISTS "Admins can read roles" ON admin_roles;
DROP POLICY IF EXISTS "Admins can read own data" ON admin_users;

-- Create base policy for admin_roles
CREATE POLICY "Admin roles base access"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

-- Create management policy for admin_roles
CREATE POLICY "Super admins manage roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);

-- Create base policy for admin_users
CREATE POLICY "Admin users base access"
ON admin_users
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);

-- Create management policy for admin_users
CREATE POLICY "Super admins manage users"
ON admin_users
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);