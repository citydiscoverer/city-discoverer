/*
  # Fix admin_roles policy recursion

  1. Changes
    - Replace recursive policy with direct role check
    - Simplify super admin verification
    - Add explicit policy for public read access

  2. Security
    - Maintains role-based access control
    - Prevents infinite recursion
    - Preserves existing security model
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Super admins can manage roles" ON admin_roles;

-- Create new non-recursive policies
CREATE POLICY "Allow super admin management"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);

-- Add public read policy for basic role information
CREATE POLICY "Allow public role viewing"
ON admin_roles
FOR SELECT
TO public
USING (true);