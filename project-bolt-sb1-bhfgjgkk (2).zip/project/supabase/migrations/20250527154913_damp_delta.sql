/*
  # Legacy User Migration
  
  1. Changes
    - Creates cities: Cumberland and Wiley Ford
    - Creates Legacy User subscription tier
    - Assigns subscription and cities to specific user
    
  2. Security
    - Maintains existing RLS policies
    - Uses proper constraint handling
*/

-- First ensure both cities exist in cities table
INSERT INTO cities (name, created_at)
VALUES 
  ('Cumberland', now()),
  ('Wiley Ford', now())
ON CONFLICT DO NOTHING;

-- Create a special tier for legacy users if it doesn't exist
INSERT INTO subscription_tiers (name, city_limit, price)
VALUES ('Legacy User', 2, 0)
ON CONFLICT DO NOTHING;

-- Get the user ID and add subscription
DO $$
DECLARE
  v_user_id uuid;
  v_tier_id uuid;
  v_cumberland_id uuid;
  v_wiley_ford_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'felixabayomi@icloud.com';

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User not found with email felixabayomi@icloud.com';
  END IF;

  -- Get tier ID
  SELECT id INTO v_tier_id
  FROM subscription_tiers
  WHERE name = 'Legacy User';

  IF v_tier_id IS NULL THEN
    RAISE EXCEPTION 'Legacy User tier not found';
  END IF;

  -- Get city IDs
  SELECT id INTO v_cumberland_id
  FROM cities
  WHERE name = 'Cumberland';

  SELECT id INTO v_wiley_ford_id
  FROM cities
  WHERE name = 'Wiley Ford';

  IF v_cumberland_id IS NULL OR v_wiley_ford_id IS NULL THEN
    RAISE EXCEPTION 'One or both cities not found';
  END IF;

  -- Insert or update subscription
  INSERT INTO user_subscriptions (user_id, tier_id, active, expires_at)
  VALUES (v_user_id, v_tier_id, true, '2099-12-31 23:59:59'::timestamptz)
  ON CONFLICT DO NOTHING;

  -- Insert city assignments if they don't exist
  INSERT INTO user_cities (user_id, city_id)
  SELECT v_user_id, unnest(ARRAY[v_cumberland_id, v_wiley_ford_id])
  ON CONFLICT DO NOTHING;

END $$;