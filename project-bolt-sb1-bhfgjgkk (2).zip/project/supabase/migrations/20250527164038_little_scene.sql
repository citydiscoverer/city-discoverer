-- Drop existing problematic policies
DROP POLICY IF EXISTS "Super admins manage roles v2" ON admin_roles;
DROP POLICY IF EXISTS "Allow authenticated to read roles" ON admin_roles;
DROP POLICY IF EXISTS "Super admins can manage roles" ON admin_roles;

-- Create new simplified policies for admin_roles
CREATE POLICY "Read admin roles"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Manage admin roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id 
      FROM admin_roles 
      WHERE name = 'super_admin'
    )
  )
);

-- Drop existing problematic policies for admin_users
DROP POLICY IF EXISTS "Super admins can manage all" ON admin_users;
DROP POLICY IF EXISTS "Users can view own record" ON admin_users;

-- Create new simplified policies for admin_users
CREATE POLICY "Read admin users"
ON admin_users
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id 
      FROM admin_roles 
      WHERE name = 'super_admin'
    )
  )
);

CREATE POLICY "Manage admin users"
ON admin_users
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id 
      FROM admin_roles 
      WHERE name = 'super_admin'
    )
  )
);