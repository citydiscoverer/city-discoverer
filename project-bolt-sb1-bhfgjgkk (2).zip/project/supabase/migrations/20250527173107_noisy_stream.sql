/*
  # Set up subscriber access and fix policies

  1. New Data
    - Add Cumberland and Wiley Ford cities
    - Create city guides for both cities
    - Create Legacy User subscription tier
    - Set up user subscription and city access for felixabayomi@icloud.com

  2. Policy Changes
    - Fix admin_roles policy recursion issues
    - Create non-recursive policies for admin role management
*/

-- First ensure both cities exist in cities table
INSERT INTO cities (id, name)
VALUES 
  (gen_random_uuid(), 'Cumberland'),
  (gen_random_uuid(), 'Wiley Ford')
ON CONFLICT (name) DO NOTHING;

-- Create city guides if they don't exist
INSERT INTO city_guides (id, city_name, state, basic_info, local_attractions, restaurants, transportation, accommodations, local_tips, history_culture, audio_guides, walking_tours, seasonal_recommendations, architecture, etiquette)
VALUES 
  (gen_random_uuid(), 'Cumberland', 'MD', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}'),
  (gen_random_uuid(), 'Wiley Ford', 'WV', '{}', '[]', '[]', '{}', '[]', '{}', '{}', '{}', '[]', '{}', '{}', '{}')
ON CONFLICT ON CONSTRAINT unique_city_state DO NOTHING;

-- Create a special tier for legacy users if it doesn't exist
INSERT INTO subscription_tiers (id, name, city_limit, price)
VALUES (gen_random_uuid(), 'Legacy User', 2, 0)
ON CONFLICT DO NOTHING;

-- Set up user subscription and cities
DO $$
DECLARE
  v_user_id uuid;
  v_tier_id uuid;
  v_cumberland_id uuid;
  v_wiley_ford_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'felixabayomi@icloud.com';

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User not found with email felixabayomi@icloud.com';
  END IF;

  -- Get tier ID
  SELECT id INTO v_tier_id
  FROM subscription_tiers
  WHERE name = 'Legacy User';

  -- Get city IDs
  SELECT id INTO v_cumberland_id
  FROM cities
  WHERE name = 'Cumberland';

  SELECT id INTO v_wiley_ford_id
  FROM cities
  WHERE name = 'Wiley Ford';

  -- Set up subscription
  INSERT INTO user_subscriptions (id, user_id, tier_id, active, expires_at)
  VALUES (
    gen_random_uuid(),
    v_user_id,
    v_tier_id,
    true,
    '2099-12-31 23:59:59'::timestamptz
  )
  ON CONFLICT (user_id) 
  DO UPDATE SET
    tier_id = EXCLUDED.tier_id,
    active = EXCLUDED.active,
    expires_at = EXCLUDED.expires_at;

  -- Add city access
  INSERT INTO user_cities (id, user_id, city_id)
  SELECT 
    gen_random_uuid(),
    v_user_id,
    city_id
  FROM (VALUES 
    (v_cumberland_id),
    (v_wiley_ford_id)
  ) AS cities(city_id)
  ON CONFLICT ON CONSTRAINT user_cities_user_id_city_id_key DO NOTHING;

END $$;

-- Fix policy recursion issues
DROP POLICY IF EXISTS "admin_roles_manage" ON admin_roles;
DROP POLICY IF EXISTS "admin_roles_read" ON admin_roles;

-- Create non-recursive policies
CREATE POLICY "admin_roles_read"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "admin_roles_manage"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);