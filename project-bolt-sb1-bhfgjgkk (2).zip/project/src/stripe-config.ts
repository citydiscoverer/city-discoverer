export const STRIPE_PRODUCTS = {
  CUSTOM_ITINERARY: {
    priceId: 'price_1RS66QDmVsICNOxP1W3eeAYT',
    name: 'City Discoverer: Custom Itinerary Pack',
    description: 'Includes:A tailored 1-3-day city plan Neighborhood-focused exploration.Restaurant, landmark, and hidden gem recommendationsLocal transit tips and walking routesDelivered as a printable and mobile-friendly PDFBest For: One-time travelers, weekend trippers, and non-members needing expert travel guidance.Positioning: "Plan the perfect city escape without a subscription."',
    mode: 'payment'
  },
  GIFT_MEMBERSHIP: {
    priceId: 'price_1RS5GCDmVsICNOxP85F3gSxR',
    name: 'City Discoverer: Gift Membership',
    description: 'Give the gift of discovery. This one-time purchase grants the recipient full access to City Discoverer\'s premium features for 12 months. Perfect for birthdays, graduations, and travel lovers.',
    mode: 'subscription'
  },
  YEARLY_EXPLORER: {
    priceId: 'price_1RS5G9DmVsICNOxPlCEK75jF',
    name: 'City Discoverer: Yearly Explorer Pass',
    description: 'Save more and explore all year long. Get 12 months of unlimited access to City Discoverer\'s premium travel content, local insights, city guides, and offline features—designed for true urban explorers.',
    mode: 'subscription'
  },
  MONTHLY_EXPLORER: {
    priceId: 'price_1RS5G5DmVsICNOxPwRgM1jKY',
    name: 'City Discoverer: Monthly Explorer Pass',
    description: 'Unlock exclusive access to our premium city insights, curated guides, local-only discoveries, and real-time travel tips in every U.S. city we cover. Perfect for travelers, digital nomads, and curious locals.',
    mode: 'subscription'
  }
} as const;

export type StripeProduct = keyof typeof STRIPE_PRODUCTS;
export type StripeMode = typeof STRIPE_PRODUCTS[StripeProduct]['mode'];