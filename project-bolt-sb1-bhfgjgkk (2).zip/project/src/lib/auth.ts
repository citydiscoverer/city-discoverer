// ✅ FINALIZED lib/auth.ts - Node-safe auth handler for API routes
import { SignJWT } from 'jose';
import { randomUUID, randomBytes, pbkdf2Sync } from 'crypto';
import { statements } from './db';

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || randomBytes(32).toString('hex'));
const JWT_ISSUER = 'city-discoverer';
const JWT_AUDIENCE = 'city-discoverer-web';

export interface User {
  id: string;
  email: string;
  metadata?: Record<string, any>;
  isAdmin?: boolean;
}

export interface Session {
  id: string;
  token: string;
  userId: string;
  expiresAt: Date;
}

const hashPassword = (password: string, salt: string) => {
  return pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
};

const generateId = () => randomUUID();
const generateToken = () => randomBytes(32).toString('hex');

export const auth = {
  async signUp(email: string, password: string, metadata?: Record<string, any>): Promise<User> {
    const salt = randomBytes(16).toString('hex');
    const passwordHash = hashPassword(password, salt);
    const id = generateId();

    try {
      statements.createUser.run(id, email, `${salt}:${passwordHash}`, JSON.stringify(metadata || {}));
      return { id, email, metadata };
    } catch (error) {
      console.error('Failed to create user:', error);
      throw new Error('Failed to create user');
    }
  },

  async signIn(email: string, password: string): Promise<{ user: User; session: Session }> {
    const user = statements.getUserByEmail.get(email);
    if (!user) throw new Error('Invalid credentials');

    const [salt, storedHash] = user.password_hash.split(':');
    const passwordHash = hashPassword(password, salt);
    if (passwordHash !== storedHash) throw new Error('Invalid credentials');

    const sessionId = generateId();
    const token = generateToken();
    const expiresAt = new Date(Date.now() + 30 * 86400000);

    statements.createSession.run(sessionId, user.id, token, expiresAt.toISOString());
    const adminRole = statements.getAdminRole.get(user.id);

    const userData: User = {
      id: user.id,
      email: user.email,
      metadata: JSON.parse(user.metadata || '{}'),
      isAdmin: !!adminRole
    };

    return {
      user: userData,
      session: {
        id: sessionId,
        token,
        userId: user.id,
        expiresAt
      }
    };
  },

  async signOut(token: string): Promise<void> {
    statements.deleteSession.run(token);
  },

  async getUserByToken(token: string): Promise<User | null> {
    const session = statements.getSessionByToken.get(token);
    if (!session) return null;

    const user = statements.getUserById.get(session.user_id);
    if (!user) {
      statements.deleteSession.run(token);
      return null;
    }

    const adminRole = statements.getAdminRole.get(user.id);

    return {
      id: user.id,
      email: user.email,
      metadata: JSON.parse(user.metadata || '{}'),
      isAdmin: !!adminRole
    };
  },

  async updateUserMetadata(userId: string, metadata: Record<string, any>): Promise<void> {
    statements.updateUserMetadata.run(JSON.stringify(metadata), userId);
  }
};
