import { auth } from '../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).end();

  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Missing token' });

  try {
    const user = await auth.getUserByToken(token);
    if (!user) return res.status(401).json({ message: 'Invalid session' });
    res.status(200).json(user);
  } catch {
    res.status(500).json({ message: 'Failed to fetch user' });
  }
}
