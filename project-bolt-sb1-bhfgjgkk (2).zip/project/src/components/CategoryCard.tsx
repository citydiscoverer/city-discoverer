import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface CategoryCardProps {
  id: string;
  title: string;
  icon: LucideIcon;
  isSelected: boolean;
  onClick: () => void;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ id, title, icon: Icon, isSelected, onClick }) => {
  const navigate = useNavigate();
  const { cityId } = useParams();

  const handleClick = () => {
    onClick();
    navigate(`/cities/${cityId}/categories/${id}`);
  };

  return (
    <button
      className={`
        w-full p-6 rounded-lg text-center flex flex-col items-center justify-center gap-4 transition-all duration-200
        ${isSelected 
          ? 'bg-blue-50 border border-blue-200 shadow-sm' 
          : 'bg-white border border-gray-200 hover:border-gray-300 hover:shadow-sm'
        }
        focus:outline-none focus:ring-2 focus:ring-blue-500
      `}
      onClick={handleClick}
      aria-pressed={isSelected}
    >
      <Icon className={`w-8 h-8 ${isSelected ? 'text-blue-600' : 'text-gray-600'}`} />
      <span className={`text-lg ${isSelected ? 'text-blue-700 font-medium' : 'text-gray-900'}`}>
        {title}
      </span>
    </button>
  );
};

export default CategoryCard;