/*
  # Fix admin policies recursion

  1. Changes
    - Drop existing policies that may cause recursion
    - Create simplified policies for admin_roles and admin_users
    - Implement proper role-based access control without circular dependencies
    
  2. Security
    - Maintain proper access control for super admins
    - Allow users to read their own data
    - Prevent unauthorized access
*/

-- First, drop all existing policies to start fresh
DROP POLICY IF EXISTS "Super admins manage users" ON admin_users;
DROP POLICY IF EXISTS "Admins can read own data" ON admin_users;
DROP POLICY IF EXISTS "Super admins can manage roles" ON admin_roles;
DROP POLICY IF EXISTS "Admins can read roles" ON admin_roles;

-- Create base policies for admin_roles
CREATE POLICY "Read admin roles"
ON admin_roles
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE user_id = auth.uid()
  )
);

-- Create management policy for admin_roles
CREATE POLICY "Manage admin roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);

-- Create read policy for admin_users
CREATE POLICY "Read admin user data"
ON admin_users
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);

-- Create management policy for admin_users
CREATE POLICY "Manage admin users"
ON admin_users
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);