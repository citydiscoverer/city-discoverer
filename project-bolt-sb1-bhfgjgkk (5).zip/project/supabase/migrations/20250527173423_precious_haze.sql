/*
  # Fix admin roles policy recursion

  1. Changes
    - Drop existing problematic policies
    - Create new non-recursive policies for admin roles
    - Simplify policy logic to prevent circular dependencies

  2. Security
    - Maintain proper access control for admin roles
    - Ensure super admins can still manage roles
    - Allow authenticated users to read roles
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "admin_roles_manage" ON admin_roles;
DROP POLICY IF EXISTS "admin_roles_read" ON admin_roles;

-- Create new non-recursive policies
CREATE POLICY "admin_roles_read"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "admin_roles_manage"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM admin_roles ar
      WHERE ar.id = au.role_id
      AND ar.name = 'super_admin'
    )
  )
);