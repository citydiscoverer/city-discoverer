/*
  # Add Legacy User and Initial Cities

  This migration sets up initial data for legacy user support:
  
  1. Creates initial cities
  2. Creates a special legacy user subscription tier
  3. Assigns the tier and cities to a specific legacy user

  Note: This migration is idempotent and can be safely re-run
*/

-- First, ensure the cities exist
INSERT INTO cities (name)
VALUES 
  ('Cumberland'),
  ('Wiley Ford')
ON CONFLICT (name) DO NOTHING;

-- Create a special tier for legacy users if it doesn't exist
INSERT INTO subscription_tiers (name, city_limit, price)
VALUES ('Legacy User', 2, 0)
ON CONFLICT (name) DO NOTHING;

-- Get the user ID for the email and assign subscription
WITH user_data AS (
  SELECT id 
  FROM auth.users 
  WHERE email = 'felixabayomii@icloud.com'
  LIMIT 1
),
tier_data AS (
  SELECT id 
  FROM subscription_tiers 
  WHERE name = 'Legacy User'
  LIMIT 1
)
INSERT INTO user_subscriptions (user_id, tier_id, active, expires_at)
SELECT 
  user_data.id,
  tier_data.id,
  true,
  '2099-12-31 23:59:59'::timestamptz
FROM user_data
CROSS JOIN tier_data
ON CONFLICT (user_id) DO UPDATE
SET 
  tier_id = EXCLUDED.tier_id,
  active = EXCLUDED.active,
  expires_at = EXCLUDED.expires_at;

-- Add user cities
WITH user_data AS (
  SELECT id 
  FROM auth.users 
  WHERE email = 'felixabayomii@icloud.com'
  LIMIT 1
),
city_data AS (
  SELECT id 
  FROM cities 
  WHERE name IN ('Cumberland', 'Wiley Ford')
)
INSERT INTO user_cities (user_id, city_id)
SELECT user_data.id, city_data.id
FROM user_data
CROSS JOIN city_data
ON CONFLICT (user_id, city_id) DO NOTHING;