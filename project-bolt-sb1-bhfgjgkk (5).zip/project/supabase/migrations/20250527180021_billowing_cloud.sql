/*
  # Add unique constraint to user_subscriptions table

  1. Changes
    - Adds a unique constraint on user_id column in user_subscriptions table
    - Ensures each user can only have one active subscription

  2. Notes
    - Uses IF NOT EXISTS to make migration idempotent
    - Constraint name follows standard naming convention
*/

-- Add unique constraint if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'user_subscriptions_user_id_key'
    AND table_name = 'user_subscriptions'
  ) THEN
    ALTER TABLE user_subscriptions
    ADD CONSTRAINT user_subscriptions_user_id_key UNIQUE (user_id);
  END IF;
END $$;