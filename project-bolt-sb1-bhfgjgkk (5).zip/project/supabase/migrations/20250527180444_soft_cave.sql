/*
  # Add Unique Constraints and Update User Metadata

  1. Constraints Added
    - user_subscriptions: unique user_id
    - subscription_tiers: unique name
    - cities: unique name and state combination
    - user_cities: unique user_id and city_id combination
    - city_guides: unique city_name and state combination

  2. User Updates
    - Updates user metadata for initial city assignment
*/

-- Add unique constraints if they don't exist
DO $$ 
BEGIN
  -- user_subscriptions unique user_id constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'user_subscriptions_user_id_key'
  ) THEN
    ALTER TABLE user_subscriptions
    ADD CONSTRAINT user_subscriptions_user_id_key UNIQUE (user_id);
  END IF;

  -- subscription_tiers unique name constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'subscription_tiers_name_key'
  ) THEN
    ALTER TABLE subscription_tiers
    ADD CONSTRAINT subscription_tiers_name_key UNIQUE (name);
  END IF;

  -- cities unique name and state constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'cities_name_state_key'
  ) THEN
    ALTER TABLE cities
    ADD CONSTRAINT cities_name_state_key UNIQUE (name, state);
  END IF;

  -- user_cities unique user_id and city_id constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'user_cities_user_id_city_id_key'
  ) THEN
    ALTER TABLE user_cities
    ADD CONSTRAINT user_cities_user_id_city_id_key UNIQUE (user_id, city_id);
  END IF;

  -- city_guides unique city_name and state constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'city_guides_city_name_state_key'
  ) THEN
    ALTER TABLE city_guides
    ADD CONSTRAINT city_guides_city_name_state_key UNIQUE (city_name, state);
  END IF;
END $$;

-- Update user metadata for initial city
DO $$
DECLARE
  v_user_id uuid;
  v_city_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'felixabayomi@icloud.com';

  IF v_user_id IS NOT NULL THEN
    -- Get Cumberland city ID
    SELECT id INTO v_city_id
    FROM cities
    WHERE name = 'Cumberland' AND state = 'MD';

    IF v_city_id IS NOT NULL THEN
      -- Update user metadata
      UPDATE auth.users
      SET raw_user_meta_data = jsonb_set(
        COALESCE(raw_user_meta_data, '{}'::jsonb),
        '{initial_city_id}',
        to_jsonb(v_city_id::text)
      )
      WHERE id = v_user_id;

      -- Also set initial city name and state
      UPDATE auth.users
      SET raw_user_meta_data = jsonb_set(
        raw_user_meta_data,
        '{initial_city_name}',
        '"Cumberland"'::jsonb
      )
      WHERE id = v_user_id;

      UPDATE auth.users
      SET raw_user_meta_data = jsonb_set(
        raw_user_meta_data,
        '{initial_state}',
        '"MD"'::jsonb
      )
      WHERE id = v_user_id;
    END IF;
  END IF;
END $$;