/*
  # Add unique constraints to tables
  
  1. Changes
    - Add unique constraint on user_subscriptions(user_id)
    - Add unique constraint on subscription_tiers(name)
    - Add unique constraint on cities(name, state)
    - Add unique constraint on user_cities(user_id, city_id)
    - Add unique constraint on city_guides(city_name, state)
  
  2. Security
    - No changes to RLS policies
    - No changes to existing permissions
*/

-- Add unique constraints if they don't exist
DO $$ 
BEGIN
  -- user_subscriptions unique user_id constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'user_subscriptions_user_id_key'
  ) THEN
    ALTER TABLE user_subscriptions
    ADD CONSTRAINT user_subscriptions_user_id_key UNIQUE (user_id);
  END IF;

  -- subscription_tiers unique name constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'subscription_tiers_name_key'
  ) THEN
    ALTER TABLE subscription_tiers
    ADD CONSTRAINT subscription_tiers_name_key UNIQUE (name);
  END IF;

  -- cities unique name and state constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'cities_name_state_key'
  ) THEN
    ALTER TABLE cities
    ADD CONSTRAINT cities_name_state_key UNIQUE (name, state);
  END IF;

  -- user_cities unique user_id and city_id constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'user_cities_user_id_city_id_key'
  ) THEN
    ALTER TABLE user_cities
    ADD CONSTRAINT user_cities_user_id_city_id_key UNIQUE (user_id, city_id);
  END IF;

  -- city_guides unique city_name and state constraint
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'city_guides_city_name_state_key'
  ) THEN
    ALTER TABLE city_guides
    ADD CONSTRAINT city_guides_city_name_state_key UNIQUE (city_name, state);
  END IF;
END $$;