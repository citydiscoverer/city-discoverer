/*
  # Fix admin role policies

  1. Changes
    - Drop existing recursive policies
    - Create simplified non-recursive policies for admin roles
    - Update related policies for admin users
  
  2. Security
    - Maintain proper access control without recursion
    - Ensure super admins can still manage roles
    - Allow authenticated users to read roles
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "admin_roles_read" ON admin_roles;
DROP POLICY IF EXISTS "admin_roles_manage" ON admin_roles;

-- Create new non-recursive policies
CREATE POLICY "read_roles"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "manage_roles"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND EXISTS (
      SELECT 1 
      FROM admin_roles ar 
      WHERE ar.id = au.role_id 
      AND ar.name = 'super_admin'
    )
  )
);

-- Update admin_users policies to match
DROP POLICY IF EXISTS "read_own_admin_user" ON admin_users;
DROP POLICY IF EXISTS "manage_admin_users" ON admin_users;

CREATE POLICY "read_admin_users"
ON admin_users
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND EXISTS (
      SELECT 1 
      FROM admin_roles ar 
      WHERE ar.id = au.role_id 
      AND ar.name = 'super_admin'
    )
  )
);

CREATE POLICY "manage_admin_users"
ON admin_users
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND EXISTS (
      SELECT 1 
      FROM admin_roles ar 
      WHERE ar.id = au.role_id 
      AND ar.name = 'super_admin'
    )
  )
);