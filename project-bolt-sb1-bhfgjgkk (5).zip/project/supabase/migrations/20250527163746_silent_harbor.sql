/*
  # Assign Cities to Existing User
  
  Assigns Cumberland, MD and Wiley Ford, WV to the specified user
*/

-- Assign cities to felixabayomi@icloud.com
DO $$
DECLARE
  v_user_id uuid;
  v_cumberland_id uuid;
  v_wiley_ford_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'felixabayomi@icloud.com';

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- Assign Cumberland, MD
  SELECT assign_city_to_user(v_user_id, 'Cumberland', 'MD')
  INTO v_cumberland_id;

  -- Assign Wiley Ford, WV
  SELECT assign_city_to_user(v_user_id, 'Wiley Ford', 'WV')
  INTO v_wiley_ford_id;

  -- Update user metadata
  UPDATE auth.users
  SET raw_user_meta_data = jsonb_build_object(
    'role', 'subscriber',
    'initial_city_id', v_cumberland_id,
    'initial_city_name', 'Cumberland',
    'initial_state', 'MD'
  )
  WHERE id = v_user_id;

END $$;