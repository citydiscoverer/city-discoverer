/*
  # Fix admin roles policy recursion

  1. Changes
    - Remove recursive policy from admin_roles table
    - Add new non-recursive policy for super admin access
    - Add policy for authenticated users to read roles

  2. Security
    - Enable RLS on admin_roles table (already enabled)
    - Replace recursive policy with safe version
    - Maintain proper access control for super admins
*/

-- Drop the problematic policy that causes recursion
DROP POLICY IF EXISTS "Super admins manage roles" ON admin_roles;

-- Create new policy for super admins that avoids recursion
CREATE POLICY "Super admins manage roles v2"
ON admin_roles
FOR ALL 
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
    -- Use a direct comparison instead of recursive check
    AND ar.id = admin_roles.id
  )
);

-- Keep the existing read policy
-- This policy is already safe and doesn't cause recursion
CREATE POLICY IF NOT EXISTS "Allow authenticated to read roles"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);