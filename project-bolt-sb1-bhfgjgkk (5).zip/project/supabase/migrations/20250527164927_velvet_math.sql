/*
  # Fix admin roles RLS policy recursion

  1. Changes
    - Remove recursive policies from admin_roles table
    - Simplify policy to check only direct role assignments
    - Add more focused policies for specific operations

  2. Security
    - Maintain security while avoiding recursion
    - Ensure admin access is properly restricted
    - Keep read access for authenticated users
*/

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS "admin_roles_manage" ON admin_roles;
DROP POLICY IF EXISTS "admin_roles_read" ON admin_roles;

-- Create new non-recursive policies
CREATE POLICY "admin_roles_manage"
ON admin_roles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.user_id = auth.uid()
    AND au.role_id IN (
      SELECT id FROM admin_roles WHERE name = 'super_admin'
    )
  )
);

CREATE POLICY "admin_roles_read"
ON admin_roles
FOR SELECT
TO authenticated
USING (true);

-- Update user_cities policies to avoid recursion
DROP POLICY IF EXISTS "Admins can manage user cities" ON user_cities;

CREATE POLICY "Admins can manage user cities"
ON user_cities
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users au
    JOIN admin_roles ar ON au.role_id = ar.id
    WHERE au.user_id = auth.uid()
    AND ar.name = 'super_admin'
  )
);