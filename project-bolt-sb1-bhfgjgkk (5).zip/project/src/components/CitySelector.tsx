import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronDown, Plus } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface City {
  id: string;
  name: string;
}

const CitySelector: React.FC = () => {
  const [cities, setCities] = useState<City[]>([]);
  const [availableCities, setAvailableCities] = useState<City[]>([]);
  const [selectedCity, setSelectedCity] = useState<City | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [isAddingCity, setIsAddingCity] = useState(false);
  const [newCityId, setNewCityId] = useState('');
  const { cityId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    const fetchCities = async () => {
      try {
        // First, fetch user's city IDs
        const { data: userCities, error: userCitiesError } = await supabase
          .from('user_cities')
          .select('city_id')
          .eq('user_id', user?.id);

        if (userCitiesError) {
          console.error('Error fetching user cities:', userCitiesError);
          return;
        }

        if (!userCities?.length) {
          setCities([]);
          return;
        }

        // Then, fetch the city details in a separate query
        const cityIds = userCities.map(uc => uc.city_id);
        const { data: cityDetails, error: cityDetailsError } = await supabase
          .from('cities')
          .select('id, name')
          .in('id', cityIds);

        if (cityDetailsError) {
          console.error('Error fetching city details:', cityDetailsError);
          return;
        }

        const accessibleCities = cityDetails || [];
        console.log('Accessible cities:', accessibleCities);
        setCities(accessibleCities);

        // Set selected city based on URL param or first available city
        if (accessibleCities.length > 0) {
          const cityToSelect = accessibleCities.find(city => city.id === cityId) || accessibleCities[0];
          setSelectedCity(cityToSelect);
          if (!cityId) {
            navigate(`/cities/${cityToSelect.id}`);
          }
        }

        // Fetch all available cities
        const { data: allCities, error: allCitiesError } = await supabase
          .from('cities')
          .select('id, name')
          .order('name');

        if (allCitiesError) {
          console.error('Error fetching available cities:', allCitiesError);
          return;
        }

        setAvailableCities(allCities || []);
      } catch (error) {
        console.error('Error in fetchCities:', error);
      }
    };

    if (user) {
      fetchCities();
    }

    // Subscribe to changes in user_cities
    const subscription = supabase
      .channel('user_cities_changes')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'user_cities', filter: `user_id=eq.${user?.id}` },
        () => {
          fetchCities();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [cityId, navigate, user]);

  const handleAddCity = async () => {
    if (!newCityId || !user) return;

    try {
      const { error } = await supabase
        .from('user_cities')
        .insert({ 
          user_id: user.id,
          city_id: newCityId 
        });

      if (error) throw error;

      setIsAddingCity(false);
      setNewCityId('');
    } catch (error) {
      console.error('Error adding city:', error);
    }
  };

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Your Cities</h2>
          <p className="text-gray-600 mt-1">Select a city to explore</p>
        </div>
        
        <button
          onClick={() => setIsAddingCity(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add City
        </button>
      </div>
      
      <div className="relative">
        <button
          className="w-full px-4 py-3 text-left bg-white border border-gray-200 rounded-lg flex justify-between items-center hover:border-gray-300 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
          onClick={() => setIsOpen(!isOpen)}
          aria-haspopup="listbox"
          aria-expanded={isOpen}
        >
          <span className="text-gray-900 text-lg">
            {selectedCity ? selectedCity.name : 'Select a city'}
          </span>
          <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-200 ${isOpen ? 'transform rotate-180' : ''}`} />
        </button>
        
        {isOpen && (
          <ul 
            className="absolute z-10 w-full mt-2 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-auto"
            role="listbox"
          >
            {cities.map((city) => (
              <li 
                key={city.id}
                className={`px-4 py-3 cursor-pointer transition-colors ${
                  selectedCity?.id === city.id 
                    ? 'bg-blue-50 text-blue-700' 
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
                onClick={() => {
                  setSelectedCity(city);
                  setIsOpen(false);
                  navigate(`/cities/${city.id}`);
                }}
                role="option"
                aria-selected={selectedCity?.id === city.id}
              >
                {city.name}
              </li>
            ))}
          </ul>
        )}
      </div>

      {isAddingCity && (
        <div className="mt-4 p-4 border rounded-lg bg-gray-50">
          <h3 className="text-lg font-medium text-gray-900 mb-3">Add a New City</h3>
          <select
            className="w-full px-3 py-2 border rounded-md mb-3"
            value={newCityId}
            onChange={(e) => setNewCityId(e.target.value)}
          >
            <option value="">Select a city to add</option>
            {availableCities
              .filter(city => !cities.some(c => c.id === city.id))
              .map(city => (
                <option key={city.id} value={city.id}>
                  {city.name}
                </option>
              ))
            }
          </select>
          <div className="flex justify-end space-x-2">
            <button
              onClick={handleAddCity}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Add
            </button>
            <button
              onClick={() => {
                setIsAddingCity(false);
                setNewCityId('');
              }}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CitySelector;