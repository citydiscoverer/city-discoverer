export interface User {
  id: string;
  email: string;
  metadata?: Record<string, any>;
  isAdmin?: boolean;
}

export interface Session {
  id: string;
  token: string;
  userId: string;
  expiresAt: Date;
}

export interface AuthError extends Error {
  code?: string;
  status?: number;
}